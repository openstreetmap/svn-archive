-----------------------------------------------------------------------
             Haiti Earthquake Response - JOSM Presets 
-----------------------------------------------------------------------

This is a collection of presets to be used in the OSM Haiti project after the
Haiti earthquake.

See http://wiki.openstreetmap.org/wiki/WikiProject_Haiti for further information.

AUTHORS
 * First version posted by user L�beck  

INSTALLATION
 * see http://wiki.openstreetmap.org/wiki/WikiProject_Haiti/JOSM
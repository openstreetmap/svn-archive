           Notes on the Supply of Ordnance Survey Digital Data
           ---------------------------------------------------

   Directory Structure
   -------------------

   The directory structure of this supplied data is shown below:

                        ROOT
                          |
                  -----------------
                 |                 |
                DOC              DATA
                                  

   The ROOT directory contains the following ASCII text files:
          o README.TXT - summary of supplied data 


   The DOC directory contains the following ASCII text files:

          o LICENCE.TXT - important licence information
          o CODELIST.TXT - lookup table of Admin/Health Codes
          o METADATA.TXT - number of postcode units in each postcode area
  	   

   
 
    

    

    
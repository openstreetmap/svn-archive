if(!dojo._hasResource["dojox.fx"]){ //_hasResource checks added by build. Do not use _hasResource directly in your code.
dojo._hasResource["dojox.fx"] = true;
dojo.provide("dojox.fx");

dojo.require("dojox.fx._base"); 

}

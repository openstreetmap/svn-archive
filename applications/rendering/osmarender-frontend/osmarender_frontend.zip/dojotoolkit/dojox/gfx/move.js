if(!dojo._hasResource["dojox.gfx.move"]){ //_hasResource checks added by build. Do not use _hasResource directly in your code.
dojo._hasResource["dojox.gfx.move"] = true;
dojo.provide("dojox.gfx.move");

dojo.require("dojox.gfx.Mover");
dojo.require("dojox.gfx.Moveable");

}

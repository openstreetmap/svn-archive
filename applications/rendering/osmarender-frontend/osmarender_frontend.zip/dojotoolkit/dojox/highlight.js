if(!dojo._hasResource["dojox.highlight"]){ //_hasResource checks added by build. Do not use _hasResource directly in your code.
dojo._hasResource["dojox.highlight"] = true;
dojo.provide("dojox.highlight");
dojo.require("dojox.highlight._base"); 

}

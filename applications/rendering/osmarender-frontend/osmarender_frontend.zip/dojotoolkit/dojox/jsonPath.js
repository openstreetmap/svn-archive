if(!dojo._hasResource["dojox.jsonPath"]){ //_hasResource checks added by build. Do not use _hasResource directly in your code.
dojo._hasResource["dojox.jsonPath"] = true;
dojo.provide("dojox.jsonPath");
dojo.require("dojox.jsonPath.query");

}

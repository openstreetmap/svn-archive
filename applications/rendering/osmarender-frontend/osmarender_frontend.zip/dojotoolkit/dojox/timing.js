if(!dojo._hasResource["dojox.timing"]){ //_hasResource checks added by build. Do not use _hasResource directly in your code.
dojo._hasResource["dojox.timing"] = true;
dojo.provide("dojox.timing");
dojo.require("dojox.timing._base"); 

}

#!/bin/sh

java -jar ../shrinksafe/custom_rhino.jar runner.js "$@"

- JTileDownloader - 

Copyright 2008, Friedrich Maier 

Project Homepage:
http://wiki.openstreetmap.org/index.php/JTileDownloader

Contact:
http://wiki.openstreetmap.org/index.php/User:Fma
mail: fr {-dot-} maier {-at-} gmx {-dot-} at
 
This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
You should have received a copy (see file COPYING.txt) of the GNU 
General Public License along with this program.  
If not, see <http://www.gnu.org/licenses/>.

-------------------------------------------------------------------------------

Downloaded data (tiles) is based on
http://www.openstreetmap.org
see http://wiki.openstreetmap.org/index.php/OpenStreetMap_License

Plase take also a look at the 'Tile usage policy'
http://wiki.openstreetmap.org/index.php/Tile_usage_policy

-------------------------------------------------------------------------------
Predefined tile servers are:
Osmarender                     http://tah.openstreetmap.org/Tiles/tile/
Mapnik                         http://tile.openstreetmap.org/mapnik/
Cyclemap (CloudMade)           http://c.andy.sandbox.cloudmade.com/tiles/cycle/
Cyclemap (Thunderflames)       http://thunderflames.org/tiles/cycle/
OpenPisteMap                   http://openpistemap.org/tiles/contours/
Maplint                        http://tah.openstreetmap.org/Tiles/maplint/
CloudMade Web style            http://tile.cloudmade.com/8bafab36916b5ce6b4395ede3cb9ddea/1/256/
CloudMade Mobile style         http://tile.cloudmade.com/8bafab36916b5ce6b4395ede3cb9ddea/2/256/
CloudMade NoNames style        http://tile.cloudmade.com/8bafab36916b5ce6b4395ede3cb9ddea/3/256/

-------------------------------------------------------------------------------
Source code of this program is available at:
http://svn.openstreetmap.org/applications/utils/downloading/JTileDownloader/



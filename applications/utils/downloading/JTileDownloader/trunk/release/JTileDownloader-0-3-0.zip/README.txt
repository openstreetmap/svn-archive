Copyright 2008, Friedrich Maier 

Project Homepage:
http://wiki.openstreetmap.org/index.php/JTileDownloader

Contact:
http://wiki.openstreetmap.org/index.php/User:Fma
mail: fr{-dot-}maier{-at-}gmx{-dot-}at
 
This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
You should have received a copy (see file COPYING.txt) of the GNU 
General Public License along with this program.  
If not, see <http://www.gnu.org/licenses/>.

-------------------------------------------------------------------------------

Source code of this program is available at:
http://svn.openstreetmap.org/applications/utils/downloading/JTileDownloader/


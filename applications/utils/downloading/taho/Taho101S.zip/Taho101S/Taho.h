// Taho.h : Haupt-Header-Datei f�r die Anwendung TAHO
//

#if !defined(AFX_TAHO_H__5B35A380_4209_46E9_8027_1CD6E407B084__INCLUDED_)
#define AFX_TAHO_H__5B35A380_4209_46E9_8027_1CD6E407B084__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// Hauptsymbole

/////////////////////////////////////////////////////////////////////////////
// CTahoApp:
// Siehe Taho.cpp f�r die Implementierung dieser Klasse
//

class CTahoApp : public CWinApp
{
public:
	CTahoApp();

// �berladungen
	// Vom Klassenassistenten generierte �berladungen virtueller Funktionen
	//{{AFX_VIRTUAL(CTahoApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementierung

	//{{AFX_MSG(CTahoApp)
		// HINWEIS - An dieser Stelle werden Member-Funktionen vom Klassen-Assistenten eingef�gt und entfernt.
		//    Innerhalb dieser generierten Quelltextabschnitte NICHTS VER�NDERN!
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ f�gt unmittelbar vor der vorhergehenden Zeile zus�tzliche Deklarationen ein.

#endif // !defined(AFX_TAHO_H__5B35A380_4209_46E9_8027_1CD6E407B084__INCLUDED_)

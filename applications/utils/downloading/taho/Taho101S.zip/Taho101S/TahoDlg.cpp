// TahoDlg.cpp : Implementierungsdatei
//

#include "stdafx.h"
#include "Taho.h"
#include "TahoDlg.h"
#include "math.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTahoDlg Dialogfeld

	char CTahopl[1000]="";

CTahoDlg::CTahoDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CTahoDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CTahoDlg)
	m_lat1 = _T("");
	m_lat2 = _T("");
	m_lon1 = _T("");
	m_lon2 = _T("");
	m_par = _T("");
	m_size = -1;
	m_url = _T("");
	m_zoom0 = FALSE;
	m_zoom1 = FALSE;
	m_zoom10 = FALSE;
	m_zoom11 = FALSE;
	m_zoom12 = FALSE;
	m_zoom13 = FALSE;
	m_zoom14 = FALSE;
	m_zoom15 = FALSE;
	m_zoom16 = FALSE;
	m_zoom17 = FALSE;
	m_zoom2 = FALSE;
	m_zoom3 = FALSE;
	m_zoom4 = FALSE;
	m_zoom5 = FALSE;
	m_zoom6 = FALSE;
	m_zoom7 = FALSE;
	m_zoom8 = FALSE;
	m_zoom9 = FALSE;
	//}}AFX_DATA_INIT
	// Beachten Sie, dass LoadIcon unter Win32 keinen nachfolgenden DestroyIcon-Aufruf ben�tigt
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
	m_zoom[0]=&m_zoom0;
	m_zoom[1]=&m_zoom1;
	m_zoom[2]=&m_zoom2;
	m_zoom[3]=&m_zoom3;
	m_zoom[4]=&m_zoom4;
	m_zoom[5]=&m_zoom5;
	m_zoom[6]=&m_zoom6;
	m_zoom[7]=&m_zoom7;
	m_zoom[8]=&m_zoom8;
	m_zoom[9]=&m_zoom9;
	m_zoom[10]=&m_zoom10;
	m_zoom[11]=&m_zoom11;
	m_zoom[12]=&m_zoom12;
	m_zoom[13]=&m_zoom13;
	m_zoom[14]=&m_zoom14;
	m_zoom[15]=&m_zoom15;
	m_zoom[16]=&m_zoom16;
	m_zoom[17]=&m_zoom17;
	m_size=0;
}

void CTahoDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CTahoDlg)
	DDX_Text(pDX, IDC_LAT_1, m_lat1);
	DDX_Text(pDX, IDC_LAT_2, m_lat2);
	DDX_Text(pDX, IDC_LON_1, m_lon1);
	DDX_Text(pDX, IDC_LON_2, m_lon2);
	DDX_Text(pDX, IDC_PAR, m_par);
	DDX_Radio(pDX, IDC_SIZE2, m_size);
	DDX_Text(pDX, IDC_URL, m_url);
	DDX_Check(pDX, IDC_ZOOM0, m_zoom0);
	DDX_Check(pDX, IDC_ZOOM1, m_zoom1);
	DDX_Check(pDX, IDC_ZOOM10, m_zoom10);
	DDX_Check(pDX, IDC_ZOOM11, m_zoom11);
	DDX_Check(pDX, IDC_ZOOM12, m_zoom12);
	DDX_Check(pDX, IDC_ZOOM13, m_zoom13);
	DDX_Check(pDX, IDC_ZOOM14, m_zoom14);
	DDX_Check(pDX, IDC_ZOOM15, m_zoom15);
	DDX_Check(pDX, IDC_ZOOM16, m_zoom16);
	DDX_Check(pDX, IDC_ZOOM17, m_zoom17);
	DDX_Check(pDX, IDC_ZOOM2, m_zoom2);
	DDX_Check(pDX, IDC_ZOOM3, m_zoom3);
	DDX_Check(pDX, IDC_ZOOM4, m_zoom4);
	DDX_Check(pDX, IDC_ZOOM5, m_zoom5);
	DDX_Check(pDX, IDC_ZOOM6, m_zoom6);
	DDX_Check(pDX, IDC_ZOOM7, m_zoom7);
	DDX_Check(pDX, IDC_ZOOM8, m_zoom8);
	DDX_Check(pDX, IDC_ZOOM9, m_zoom9);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CTahoDlg, CDialog)
	//{{AFX_MSG_MAP(CTahoDlg)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_CMD, OnCmd)
	ON_BN_CLICKED(IDC_DO_TAHO, OnDoTaho)
	ON_BN_CLICKED(IDC_SIZE2, OnSize2)
	ON_BN_CLICKED(IDC_SIZE3, OnSize3)
	ON_BN_CLICKED(IDC_SIZE4, OnSize4)
	ON_BN_CLICKED(IDC_SIZE5, OnSize5)
	ON_BN_CLICKED(IDC_URL2COORD, OnUrl2coord)
	ON_BN_CLICKED(IDC_Z_0, OnZ0)
	ON_BN_CLICKED(IDC_Z_2, OnZ2)
	ON_BN_CLICKED(IDC_Z_3, OnZ3)
	ON_BN_CLICKED(IDC_Z_ALL, OnZAll)
	ON_BN_CLICKED(IDC_HELP_ENGL, OnHelp)
	ON_BN_CLICKED(IDC_HELP_DEU, OnHilfe)
	ON_BN_CLICKED(IDC_DOCU, OnDocu)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTahoDlg Nachrichten-Handler

BOOL CTahoDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Symbol f�r dieses Dialogfeld festlegen. Wird automatisch erledigt
	//  wenn das Hauptfenster der Anwendung kein Dialogfeld ist
	SetIcon(m_hIcon, TRUE);			// Gro�es Symbol verwenden
	SetIcon(m_hIcon, FALSE);		// Kleines Symbol verwenden
	
	ShellExecute(NULL,"open","http://www.openstreetmap.org/export/","","NULL",SW_SHOW );
	
	return TRUE;  // Geben Sie TRUE zur�ck, au�er ein Steuerelement soll den Fokus erhalten
}

// Wollen Sie Ihrem Dialogfeld eine Schaltfl�che "Minimieren" hinzuf�gen, ben�tigen Sie 
//  den nachstehenden Code, um das Symbol zu zeichnen. F�r MFC-Anwendungen, die das 
//  Dokument/Ansicht-Modell verwenden, wird dies automatisch f�r Sie erledigt.

void CTahoDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // Ger�tekontext f�r Zeichnen

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Symbol in Client-Rechteck zentrieren
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Symbol zeichnen
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// Die Systemaufrufe fragen den Cursorform ab, die angezeigt werden soll, w�hrend der Benutzer
//  das zum Symbol verkleinerte Fenster mit der Maus zieht.
HCURSOR CTahoDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

//Erzeugt ein CMD-File mit den taho.pl-Aufrufen
void CTahoDlg::OnCmd() 
{
	CFileDialog dlg(FALSE,"cmd","*.cmd");
	UpdateData(TRUE);
	if(dlg.DoModal()!=IDOK)
		return;
	writeCmdOrExec(dlg.GetPathName());
	
}

void CTahoDlg::OnDoTaho() 
{
	UpdateData(TRUE);
	writeCmdOrExec("");
	
}

void CTahoDlg::OnSize2() 
{
	GetDlgItem(IDC_ZOOM2)->EnableWindow(TRUE);//Enables
	GetDlgItem(IDC_ZOOM3)->EnableWindow(TRUE);//Enables
	GetDlgItem(IDC_ZOOM4)->EnableWindow(TRUE);//Enables
	
}

void CTahoDlg::OnSize3() 
{
	GetDlgItem(IDC_ZOOM2)->EnableWindow(FALSE);//Disable
	GetDlgItem(IDC_ZOOM3)->EnableWindow(TRUE);//Enables
	GetDlgItem(IDC_ZOOM4)->EnableWindow(TRUE);//Enables
	
}

void CTahoDlg::OnSize4() 
{
	GetDlgItem(IDC_ZOOM2)->EnableWindow(FALSE);//Disable
	GetDlgItem(IDC_ZOOM3)->EnableWindow(FALSE);//Disable
	GetDlgItem(IDC_ZOOM4)->EnableWindow(TRUE);//Enables
	
}

void CTahoDlg::OnSize5() 
{
	GetDlgItem(IDC_ZOOM2)->EnableWindow(FALSE);//Disable
	GetDlgItem(IDC_ZOOM3)->EnableWindow(FALSE);//Disable
	GetDlgItem(IDC_ZOOM4)->EnableWindow(FALSE);//Disable
	
}

void CTahoDlg::OnUrl2coord() 
{
	int pos1,pos2,posz=-1,zoom=-1;

	UpdateData(TRUE);
	pos1=m_url.Find("?bbox")+6;
	if(pos1>5)
	{
// Eine URL wie man sie erh�lt wenn man auf www.openstreetmap.org auf Export geht, dort einen Bereich w�hlt,
// "Embeddeble HTML ausw�hlt:
// <iframe width="425" height="350" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" 
//  src="http://www.openstreetmap.org/export/embed.html?bbox=6.0444,50.7543,6.1553,50.7886&layer=mapnik" 
//  style="border: 1px solid black"></iframe><br /><small>
//	<a href="http://www.openstreetmap.org/?lat=50.77145&lon=6.09985&zoom=13&layers=B00FTFTT">View Larger Map</a></small>

		pos2=m_url.Find(",",pos1)+1;
		if(pos2>0)
		{
			int pos3;
			pos3=m_url.Find(",",pos2)+1;
			if(pos3>0)
			{
				int pos4;
				pos4=m_url.Find(",",pos3)+1;
				posz=m_url.Find("&zoom");
				m_lon1=m_url.Mid(pos1).SpanIncluding("-0123456789.");
				m_lat2=m_url.Mid(pos2).SpanIncluding("-0123456789.");
				m_lon2=m_url.Mid(pos3).SpanIncluding("-0123456789.");
				m_lat1=m_url.Mid(pos4).SpanIncluding("-0123456789.");
				if(posz>-1)
					zoom=atoi(m_url.Mid(posz+6));
				m_url="";
			}
		}
	}
	else // dann ist es vieleicht eine URL von sdsnetz wie diese:
//http://sdsnetz.de/glopus/glopus.php?t=1&n=50.7778024997027&s=50.77295157419221&w=6.081340312957764&o=6.088507175445557&z=17#ende
	{
		pos1=m_url.Find("&n=")+3;
		if(pos1>3)
		{
			int pos2,pos3,pos4;
			pos2=m_url.Find("&s=")+3;
			pos3=m_url.Find("&w=")+3;
			pos4=m_url.Find("&o=")+3;
			posz=m_url.Find("&z=")+3;
			if(pos2>3 && pos3>3 && pos4>0)
			{
				m_lat1=m_url.Mid(pos1).SpanIncluding("-0123456789.");
				m_lat2=m_url.Mid(pos2).SpanIncluding("-0123456789.");
				m_lon1=m_url.Mid(pos3).SpanIncluding("-0123456789.");
				m_lon2=m_url.Mid(pos4).SpanIncluding("-0123456789.");
				if(posz>3)
					zoom=atoi(m_url.Mid(posz));
				m_url="";
			}
		}
	}
	if(zoom>-1)
	{
		for(int i=0;i<18;i++)
			*m_zoom[i]=FALSE;
		*m_zoom[zoom]=TRUE;
	}
	UpdateData(FALSE);

	
}

void CTahoDlg::OnZ0() 
{
	UpdateData(TRUE);
	for(int i=0;i<18;i++)
		*m_zoom[i]=FALSE;
	UpdateData(FALSE);
	
}

void CTahoDlg::OnZ2() 
{
	int i;
	UpdateData(TRUE);
	for(i=0;i<18;i+=2)
		*m_zoom[i]=TRUE;
	for(i=1;i<18;i+=2)
		*m_zoom[i]=FALSE;

	UpdateData(FALSE);
}

void CTahoDlg::OnZ3() 
{
	int i;
	UpdateData(TRUE);
	for(i=0;i<18;i+=3)
		*m_zoom[i]=TRUE;
	for(i=1;i<18;i+=3)
		*m_zoom[i]=FALSE;
	for(i=2;i<18;i+=3)
		*m_zoom[i]=FALSE;

	UpdateData(FALSE);
	
}

void CTahoDlg::OnZAll() 
{
	UpdateData(TRUE);
	for(int i=0;i<18;i++)
		*m_zoom[i]=TRUE;

	UpdateData(FALSE);
}

// taho.pl suchen, zuerst im eigenen Verzeichnis, dann User fragen
BOOL findTahoPl(void)
{
	char *ptr;
	CFileFind finder;
	BOOL ok=TRUE;
	if(!CTahopl[0])
	{
		GetModuleFileName(NULL,CTahopl,1000);
		ptr=strrchr(CTahopl,'\\');
		if(ptr)
			strcpy(ptr+1,"taho.pl");
		if(ok && (!ptr || !finder.FindFile(CTahopl)))
		{
			CFileDialog dlg(TRUE,"pl","taho.pl");
			if(dlg.DoModal()==IDOK)
				strcpy(CTahopl,dlg.GetPathName());
			else
				ok=FALSE;
		}
	}
	return(ok);
}
BOOL CTahoDlg::writeCmdOrExec(CString path)
{
	FILE *fCmd=NULL;
	BOOL ok=TRUE;
	double lon1,lon2,lat1,lat2;
	int size=m_size+2;
	lon1=atof(m_lon1);
	lat1=atof(m_lat1);
	lon2=atof(m_lon2);
	lat2=atof(m_lat2);
	if(lon1<-180 ||lon1>180 || lat1<-90 ||lat1>90||lon2<-180 ||lon2>180 || lat2<-90 ||lat2>90)
		ok=FALSE;
//CMD-File �ffnen falls gew�nscht
	else if(!path.IsEmpty())
	{
		fCmd=fopen(path,"w");
		if(!fCmd)
			ok=FALSE;
	}
	ok=findTahoPl();
	if(ok)
	{
		for(int zooml=size;zooml<18;zooml++)
		{
			if(*m_zoom[zooml])
			{
				char cmd[1000];
				sprintf(cmd,"-coord=\"%d,%f,%f\" -coord2=\"%f,%f\" -size=%d %s",zooml-size,lat1,lon1,lat2,lon2,size,m_par);
				if(fCmd)
					fprintf(fCmd,"%s %s\n",CTahopl,cmd);
				else
					ShellExecute(NULL,"open",CTahopl,cmd,"NULL",SW_SHOW );
			}
		}
		if(fCmd)
			fclose(fCmd);
	}
	return ok;

}






void CTahoDlg::OnHelp() 
{
	ShellExecute(NULL,"open","./Docu/readme.pdf","","NULL",SW_SHOW );
	
}

void CTahoDlg::OnHilfe() 
{
	ShellExecute(NULL,"open","./Docu/liesmich.pdf","","NULL",SW_SHOW );
	
}

void CTahoDlg::OnDocu() 
{
	ShellExecute(NULL,"open","http://wiki.openstreetmap.org/index.php/Oziexplorer#Generate_an_pixel_map_with_calibration_using_tiles.40home_tiles","","NULL",SW_SHOW );
	
}

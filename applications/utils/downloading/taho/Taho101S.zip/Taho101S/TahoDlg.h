// TahoDlg.h : Header-Datei
//

#if !defined(AFX_TAHODLG_H__B3F1D0AA_1663_463B_8F24_450420E58CA5__INCLUDED_)
#define AFX_TAHODLG_H__B3F1D0AA_1663_463B_8F24_450420E58CA5__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CTahoDlg Dialogfeld

class CTahoDlg : public CDialog
{
// Konstruktion
public:
	BOOL * m_zoom[18];
	BOOL writeCmdOrExec(CString path);
	CTahoDlg(CWnd* pParent = NULL);	// Standard-Konstruktor

// Dialogfelddaten
	//{{AFX_DATA(CTahoDlg)
	enum { IDD = IDD_TAHO_DIALOG };
	CString	m_lat1;
	CString	m_lat2;
	CString	m_lon1;
	CString	m_lon2;
	CString	m_par;
	int		m_size;
	CString	m_url;
	BOOL	m_zoom0;
	BOOL	m_zoom1;
	BOOL	m_zoom10;
	BOOL	m_zoom11;
	BOOL	m_zoom12;
	BOOL	m_zoom13;
	BOOL	m_zoom14;
	BOOL	m_zoom15;
	BOOL	m_zoom16;
	BOOL	m_zoom17;
	BOOL	m_zoom2;
	BOOL	m_zoom3;
	BOOL	m_zoom4;
	BOOL	m_zoom5;
	BOOL	m_zoom6;
	BOOL	m_zoom7;
	BOOL	m_zoom8;
	BOOL	m_zoom9;
	//}}AFX_DATA

	// Vom Klassenassistenten generierte �berladungen virtueller Funktionen
	//{{AFX_VIRTUAL(CTahoDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV-Unterst�tzung
	//}}AFX_VIRTUAL

// Implementierung
protected:
	HICON m_hIcon;

	// Generierte Message-Map-Funktionen
	//{{AFX_MSG(CTahoDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void On2pkt();
	afx_msg void OnCmd();
	afx_msg void OnDoTaho();
	afx_msg void OnMpktGr();
	afx_msg void OnSize2();
	afx_msg void OnSize3();
	afx_msg void OnSize4();
	afx_msg void OnSize5();
	afx_msg void OnUrl2coord();
	afx_msg void OnZ0();
	afx_msg void OnZ2();
	afx_msg void OnZ3();
	afx_msg void OnZAll();
	afx_msg void OnHelp();
	afx_msg void OnHilfe();
	afx_msg void OnDocu();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ f�gt unmittelbar vor der vorhergehenden Zeile zus�tzliche Deklarationen ein.

#endif // !defined(AFX_TAHODLG_H__B3F1D0AA_1663_463B_8F24_450420E58CA5__INCLUDED_)

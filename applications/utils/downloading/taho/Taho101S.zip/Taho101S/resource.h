//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Taho.rc
//
#define IDD_TAHO_DIALOG                 102
#define IDR_MAINFRAME                   128
#define IDC_LAT_1                       1000
#define IDC_LON_1                       1003
#define IDC_URL                         1004
#define IDC_URL2COORD                   1005
#define IDC_ZOOM1                       1006
#define IDC_ZOOM2                       1007
#define IDC_ZOOM3                       1008
#define IDC_ZOOM4                       1009
#define IDC_ZOOM5                       1010
#define IDC_ZOOM6                       1011
#define IDC_ZOOM0                       1012
#define IDC_ZOOM7                       1013
#define IDC_ZOOM9                       1014
#define IDC_ZOOM10                      1015
#define IDC_ZOOM11                      1016
#define IDC_ZOOM12                      1017
#define IDC_ZOOM13                      1018
#define IDC_ZOOM14                      1019
#define IDC_ZOOM8                       1020
#define IDC_ZOOM15                      1021
#define IDC_ZOOM16                      1022
#define IDC_ZOOM17                      1023
#define IDC_Z_ALL                       1024
#define IDC_Z_0                         1025
#define IDC_Z_2                         1026
#define IDC_Z_3                         1027
#define IDC_LAT_2                       1028
#define IDC_LON_2                       1029
#define IDC_BUTTON2                     1030
#define IDC_HELP_DEU                    1030
#define IDC_HELP_ENGL                   1033
#define IDC_CMD                         1034
#define IDC_DO_TAHO                     1035
#define IDC_DOCU                        1036
#define IDC_PAR                         1037
#define IDC_SIZE2                       1044
#define IDC_SIZE3                       1045
#define IDC_SIZE4                       1046
#define IDC_SIZE5                       1047

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        133
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1037
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif

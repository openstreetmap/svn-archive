This is my binary public stuff for Win32.
Since I'm not given support you can get their source code from http://nsis.sourceforge.net/Joel_plugin_src
Code and binaries are under the license of GPL (http://www.gnu.org/copyleft/gpl.html) 

# Generado en fecha: 2009-01-03 18:25:57 por Directory Lister v0.7.2

----------------------------------------------------------------------------------------
Q:\joel\CD\www\files\ (19)                                711,872 2009-01-03 18:25 -----
----------------------------------------------------------------------------------------
*Nsis related:
cabdll.zip                                                 42,963 2006-07-30 05:25 -a---
colorsel2.zip                                              37,942 2006-07-30 05:25 -a---
dialogs.zip                                                22,040 2006-07-30 05:25 -a---
dialogsex.zip                                             120,692 2006-07-30 05:25 -a---
floatop.zip                                                22,821 2006-07-30 05:25 -a---
internet.zip                                               11,879 2006-07-30 05:25 -a---
msibanner.zip                                               4,748 2006-07-30 05:25 -a---
nsbb.zip                                                    2,231 2007-06-20 05:20 -a---
nsisxml.zip                                                34,153 2006-07-30 05:25 -a---
nsweb.zip                                                  71,958 2006-07-30 05:25 -a---
sys_tut.zip                                                85,098 2006-07-30 05:25 -a---
tooltips.zip                                                4,139 2006-07-30 05:25 -a---
transisdl.zip                                              27,194 2006-07-30 05:25 -a---

*Winamp related:
waxmlpl.zip                                                59,300 2006-07-30 05:25 -a---
gen_waren.zip                                               9,467 2006-08-16 06:05 -a---
gen_warenamer.zip                                          88,824 2007-06-05 05:24 -a---
globorola.zip                                              27,051 2006-07-30 05:25 -a---
ipamp.zip                                                  37,377 2006-07-30 05:25 -a---

*X-Chat related:
xwinampt.zip                                                1,995 2006-07-30 05:25 -a---

// Microsoft CAB SDK of FDI.h adpated for NSIS by Lobo Lunar

// Functions to handle the cab:
FNALLOC(mem_alloc)
{
	return malloc(cb);
}

FNFREE(mem_free)
{
	free(pv);
}

FNOPEN(file_open)
{
	return _open(pszFile, oflag, pmode);
}

FNREAD(file_read)
{
	return _read(hf, pv, cb);
}

FNWRITE(file_write)
{
	return _write(hf, pv, cb);
}

FNCLOSE(file_close)
{
	return _close(hf);
}

FNSEEK(file_seek)
{
	return _lseek(hf, dist, seektype);
}

// Errors handlers:
char *return_fdi_error_string(FDIERROR err)
{
	switch (err)
	{
		case FDIERROR_NONE:
			return "No error";

		case FDIERROR_CABINET_NOT_FOUND:
			return "Cabinet not found";
			
		case FDIERROR_NOT_A_CABINET:
			return "Not a cabinet";
			
		case FDIERROR_UNKNOWN_CABINET_VERSION:
			return "Unknown cabinet version";
			
		case FDIERROR_CORRUPT_CABINET:
			return "Corrupt cabinet";
			
		case FDIERROR_ALLOC_FAIL:
			return "Memory allocation failed";
			
		case FDIERROR_BAD_COMPR_TYPE:
			return "Unknown compression type";
			
		case FDIERROR_MDI_FAIL:
			return "Failure decompressing data";
			
		case FDIERROR_TARGET_FILE:
			return "Failure writing to target file";
			
		case FDIERROR_RESERVE_MISMATCH:
			return "Cabinets in set have different RESERVE sizes";
			
		case FDIERROR_WRONG_CABINET:
			return "Cabinet returned on fdintNEXT_CABINET is incorrect";
			
		case FDIERROR_USER_ABORT:
			return "User aborted";
			
		default:
			return "Unknown error";
	}
}
// View the contents of the CAB (no extraction)
HWND g_hwndlist = NULL;

FNFDINOTIFY(Cab_View)
{
	char logmsg[MAX_PATH];
	switch (fdint)
	{
	case fdintCOPY_FILE:
		{
			wsprintf(logmsg, "%s (%d bytes)", pfdin->psz1, pfdin->cb);
			LogMessage(g_hwndlist, logmsg);
			return 0;
		}
	}
	return 0;
}

// View the contents of the CAB (with extraction)
char sztarget[MAX_PATH];

FNFDINOTIFY(Cab_ExtractAll)
{
	char logmsg[MAX_PATH];
	switch (fdint)
	{
	case fdintCOPY_FILE:
		{
			int		handle;
			char	destination[256];
			wsprintf(logmsg, "%s (%d bytes)", pfdin->psz1, pfdin->cb);
			LogMessage(g_hwndlist, logmsg);
			wsprintf(destination, "%s\\%s", sztarget, pfdin->psz1);
			handle = file_open(destination, _O_BINARY|_O_CREAT|_O_WRONLY|_O_SEQUENTIAL,	_S_IREAD|_S_IWRITE);
			return handle;
		}
	case fdintCLOSE_FILE_INFO:
        {
            HANDLE  handle;
            DWORD   attrs;
            char    destination[256];
			wsprintf(destination, "%s\\%s", sztarget, pfdin->psz1);
			file_close(pfdin->hf);
            handle = CreateFile(destination, GENERIC_READ|GENERIC_WRITE, FILE_SHARE_READ, NULL,OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);

            if (handle != INVALID_HANDLE_VALUE)
            {
                FILETIME    datetime;
				if (TRUE == DosDateTimeToFileTime(pfdin->date,pfdin->time,&datetime))
                {
                    FILETIME  local_filetime;
					if (TRUE == LocalFileTimeToFileTime(&datetime,&local_filetime))
                    {
                        (void) SetFileTime(handle,&local_filetime,NULL,&local_filetime);
					}
                }
                CloseHandle(handle);
            }
            attrs = pfdin->attribs;
            attrs &= (_A_RDONLY|_A_HIDDEN|_A_SYSTEM|_A_ARCH);
            (void) SetFileAttributes(destination,attrs);
			return TRUE;
        }
	}
	return 0;
}

// Process teh cab:
BOOL Cab_Info(char* cabinet_fullpath, char* targetpath, int action, HWND hwndParent)
{
	HFDI			hfdi;
	ERF				erf;
	FDICABINETINFO	fdici;
	int				hf;
	char			*p;
	char			cabinet_name[256];
	char			cabinet_path[256];
	char			err[256];

	// Create the general function prototype for the future CAB:
	hfdi = FDICreate(mem_alloc,mem_free,file_open,file_read,file_write,file_close,file_seek,cpu80386,&erf);

	// Since our function failed <_<
	if (hfdi == NULL)
	{
		// Tell the user wich code and description generate the error, later of that abort.
		wsprintf(err, "Error code: [%d]\n%s", erf.erfOper, return_fdi_error_string((FDIERROR)erf.erfOper));
		MessageBox(0, err, "Error on FDICreate", 16);
		return FALSE;
	}

	// Ok, we have green light, so test if the inputed CAB is really a CAB format:
	hf = file_open(cabinet_fullpath,_O_BINARY|_O_RDONLY|_O_SEQUENTIAL,0);

	// If the cab is corrupted:
	if (hf == -1)
	{
		// Tell the user wich code and description generate the error, later of that abort.
		wsprintf(err, "Error code: [%d]\n%s", erf.erfOper, return_fdi_error_string((FDIERROR)erf.erfOper));
		MessageBox(0, err, "Unable to open the CAB", 16);
		// Free and destroy the resources use by the cab inputed:
		(void) FDIDestroy(hfdi);
		return FALSE;
	}

	// Or maybe a "kid" is playing with us and use another format
	if (FALSE == FDIIsCabinet(hfdi,hf,&fdici))
	{
		// Close the file open by the "CAB":
		_close(hf);
		// Tell the user wich code and description generate the error, later of that abort.
		wsprintf(err, "Error code: [%d]\n%s", erf.erfOper, return_fdi_error_string((FDIERROR)erf.erfOper));
		MessageBox(0, err, "Is not a CAB", 16);
		// Free and destroy the resources use by the cab inputed:
		(void) FDIDestroy(hfdi);
		return FALSE;
	}
	else
	{
		// Wow! We made it. So, since we still got "green light" and it's a valid CAB..
		// Begin the process of the info:
		_close(hf);

		char* cbCabinet = new char[256];
		char* cFolders = new char[256];
		char* cFiles = new char[256];
		char* setID = new char[256];
		char* iCabinet = new char[256];
		char* fReserve = new char[256];
		char* hasprev = new char[256];
		char* hasnext = new char[256];
		
		wsprintf(cbCabinet, "%d", fdici.cbCabinet);
		wsprintf(cFolders, "%d", fdici.cFolders);
		wsprintf(cFiles, "%d", fdici.cFiles);
		wsprintf(setID, "%d", fdici.setID);
		wsprintf(iCabinet, "%d", fdici.iCabinet);
		wsprintf(fReserve, "%s", fdici.fReserve == TRUE ? "yes" : "no");
		wsprintf(hasprev, "%s",	fdici.hasprev == TRUE ? "yes" : "no");
		wsprintf(hasnext, "%s",	fdici.hasnext == TRUE ? "yes" : "no");

		setuservariable(0, cbCabinet);
		setuservariable(1, cFolders);
		setuservariable(2, cFiles);
		setuservariable(3, setID);
		setuservariable(4, iCabinet);
		setuservariable(5, fReserve);
		setuservariable(6, hasprev);
		setuservariable(7, hasnext);

		delete[] cbCabinet;
		delete[] cFolders;
		delete[] cFiles;
		delete[] setID;
		delete[] iCabinet;
		delete[] fReserve;
		delete[] hasprev;
		delete[] hasnext;
	}

	p = strrchr(cabinet_fullpath, '\\');

	if (p == NULL)
	{
		strcpy(cabinet_name, cabinet_fullpath);
		strcpy(cabinet_path, "");
	}
	else
	{
		strcpy(cabinet_name, p+1);

		strncpy(cabinet_path, cabinet_fullpath, (int) (p-cabinet_fullpath)+1);
		cabinet_path[ (int) (p-cabinet_fullpath)+1 ] = 0;
	}

	if (action == 1)
	{
		HWND hwnd = FindWindowEx(hwndParent,NULL,"#32770",NULL);
		g_hwndlist = FindWindowEx(hwnd, NULL,"SysListView32", NULL);
		if (TRUE != FDICopy(hfdi,cabinet_name,cabinet_path,0,Cab_View,NULL,NULL))
		{
			// Tell the user wich code and description generate the error, later of that abort.
			wsprintf(err, "Error code: [%d]\n%s", erf.erfOper, return_fdi_error_string((FDIERROR)erf.erfOper));
			MessageBox(0, err, "FDICopy error", 16);
		}
		(void) FDIDestroy(hfdi);
		return FALSE;
	}

	if (action == 2)
	{
		HWND hwnd = FindWindowEx(hwndParent,NULL,"#32770",NULL);
		g_hwndlist = FindWindowEx(hwnd, NULL,"SysListView32", NULL);
		lstrcpy(sztarget, targetpath);
		if (TRUE != FDICopy(hfdi,cabinet_name,cabinet_path,0,Cab_ExtractAll,NULL,NULL))
		{
			// Tell the user wich code and description generate the error, later of that abort.
			wsprintf(err, "Error code: [%d]\n%s", erf.erfOper, return_fdi_error_string((FDIERROR)erf.erfOper));
			MessageBox(0, err, "FDICopy error", 16);
		}
		(void) FDIDestroy(hfdi);
		return FALSE;
	}

	// This is the end of the hole resource free handler of the entire CAB, ok?
	if (FDIDestroy(hfdi) != TRUE)
	{
		// Tell the user wich code and description generate the error, later of that abort.
		wsprintf(err, "Error code: [%d]\n%s", erf.erfOper, return_fdi_error_string((FDIERROR)erf.erfOper));
		MessageBox(0, err, "FDIDestroy error", 16);
		return FALSE;
	}

	return TRUE;
}
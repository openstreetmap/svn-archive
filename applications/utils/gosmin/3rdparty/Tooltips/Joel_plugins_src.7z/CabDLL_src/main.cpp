#pragma comment(lib, "fdi.lib")
#pragma comment(lib, "comctl32.lib")

#include <windows.h>
#include <commctrl.h>
#include <io.h>
#include <fcntl.h>
#include <dos.h>
#include <sys/stat.h>
#include <fdi.h>
#include "nsisdll.h"
#include "cabdll.h"

HINSTANCE hInst;

#define Function(name) extern "C" void __declspec(dllexport) name(HWND hwndParent, int string_size, char *variables, stack_t **stacktop)

Function(Author)
{
	EXDLL_INIT();
	{
		char ret[1];
		popstring(ret);
		setuservariable(mi_atoi(ret), "Lobo Lunar");
	}
}

Function(CabInfo)
{
	EXDLL_INIT();
	{
		char szcab[MAX_PATH];
		popstring(szcab);
		if (Cab_Info(szcab, NULL, 0, 0))
		{
			setuservariable(10, "0");
		}
		else
		{
			setuservariable(10, "1");
		}
	}
}

Function(CabView)
{
	EXDLL_INIT();
	{
		char szcab[MAX_PATH];
		popstring(szcab);
		if (Cab_Info(szcab, NULL, 1, hwndParent))
		{
			setuservariable(10, "0");
		}
		else
		{
			setuservariable(10, "1");
		}
	}
}

Function(CabExtractAll)
{
	EXDLL_INIT();
	{
		char szcab[MAX_PATH]; char sztarget[MAX_PATH];
		popstring(szcab); popstring(sztarget);
		if (Cab_Info(szcab, sztarget, 2, hwndParent))
		{
			setuservariable(10, "0");
		}
		else
		{
			setuservariable(10, "1");
		}
	}
}

BOOL WINAPI DllMain(HINSTANCE hinstDLL, DWORD fdwReason, LPVOID lpReserved)
{
	hInst = hinstDLL;
	return TRUE;
}
int mi_strlen(char* InputString)
{
	int i = 0;
	while(*InputString)
	{
		i++;
		InputString++;
	}
	return i;
}

void mi_strncpy(char* Buffer, char* StringToCopy, int NumberOfCharsToCopy)
{
	int index = 0;
	for(int i = 0; i < NumberOfCharsToCopy; i++)
	{
		Buffer[index] = StringToCopy[i];
		index++;
	}
	Buffer[index] = 0;
}

void mi_strcpy(char* Buffer, char* StringToCopy)
{
	int index = 0;
	for(int i = 0; i < mi_strlen(StringToCopy); i++)
	{
		Buffer[index] = StringToCopy[i];
		index++;
	}
	Buffer[index] = 0;
}

int mi_atoi(char *StringToInteger)
{
	unsigned int v=0;
	for (;;)
	{
		int c=*StringToInteger++ - '0';
		if (c < 0 || c > 9) break;
		v*=10;
		v+=c;
	}
  return (int)v;
}

void LogMessage(HWND g_hwndList, const char *pStr)
{
	LVITEM item = {0};
	int nItemCount = SendMessage(g_hwndList, LVM_GETITEMCOUNT, 0, 0);
	item.mask = LVIF_TEXT;
	item.pszText = (char *)pStr;
	item.cchTextMax = strlen(pStr);
	item.iItem = nItemCount;
	ListView_InsertItem(g_hwndList, &item);
    ListView_EnsureVisible(g_hwndList, item.iItem, 0);
    return;
}
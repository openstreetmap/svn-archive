#pragma comment(lib, "libctiny.lib")
#pragma comment(lib, "comctl32.lib")

#include <windows.h>
#include <commctrl.h>
#include "nsisdll.h"

#define Function(name) extern "C" void __declspec(dllexport) name(HWND hwndParent, int string_size, char *variables, stack_t **stacktop)

#define IDC_MSIBANNERTEXT		1001
#define IDC_MSIBANNERICON		1002
#define IDC_PROGRESSBAR			1003
#define IDC_MSIBANNERPTJ		1004

typedef struct
{
	HWND hwndNSISParent;
	HINSTANCE hNSISInstance;
	LPTSTR lpszMSIBannerTitle;
	LPTSTR lpszMSIBannerText;
	HICON hIconMSIBanner;
	int x;
	int y;
} MSIBANNERINFO;

HINSTANCE hInst; // Global Instance
HWND hwndNSIS; // Copy of the current handle of the dialog
HWND hwndMSIBanner; // handle of the future dialog
HANDLE hMSIBanner; // handle of the future thread
HWND hMSIBannerText; // handle of the text
HWND hMSIBannerIcon; // handle of the icon
HWND hMSIBannerP;
HICON hIcon; // handle of the temp icon
HWND hPB; // handle of the progress bar
int increase; // counter for the progress bar


BOOL CALLBACK MSIBannerProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam) 
{

	switch(msg)
	{
	case WM_INITDIALOG:
		{
			increase = 0;
			INITCOMMONCONTROLSEX iccx;
			ZeroMemory(&iccx, sizeof(INITCOMMONCONTROLSEX));

			iccx.dwSize = sizeof(INITCOMMONCONTROLSEX);
			iccx.dwICC = ICC_PROGRESS_CLASS;

			InitCommonControlsEx(&iccx);

			hwndMSIBanner = hwnd;
			hMSIBannerText = CreateStatic(hwnd, IDC_MSIBANNERTEXT, "", SS_LEFT|WS_CHILD|WS_VISIBLE , 45, 7, 250, 40);
			hMSIBannerIcon = CreateStatic(hwnd, IDC_MSIBANNERICON, "", SS_ICON|WS_CHILD|WS_VISIBLE, 7, 7, 32, 32);
			hMSIBannerP = CreateStatic(hwnd, IDC_MSIBANNERPTJ, "", WS_CHILD|WS_VISIBLE, 295, 60, 60, 20);
			SendMessage(hMSIBannerIcon, STM_SETICON, (WPARAM)hIcon, 0);
			SetDefaultFont(hMSIBannerText);
			SetDefaultFont(hMSIBannerP);
			hPB = CreatePB(hwnd, WS_CHILD|WS_VISIBLE|PBS_SMOOTH, 45, 60, 250, 17);
			SendMessage(hPB, PBM_SETRANGE, 0, MAKELPARAM(0,100)); 
			SendMessage(hPB, PBM_SETSTEP, 5, 0);
			SendMessage(hPB, PBM_SETPOS, 0, 0);
			return TRUE;
		}
	case WM_DESTROY:
		{
			DestroyIcon(hIcon);
			DestroyWindow(hPB);
			DestroyWindow(hMSIBannerText);
			DestroyWindow(hMSIBannerIcon);
			DestroyWindow(hMSIBannerP);
			CloseHandle(hMSIBanner);
			return TRUE;
		}
	case WM_CLOSE:
		{
			EndDialog(hwnd, 0);
			return TRUE;
		}
	}

	return FALSE;
}

DWORD WINAPI CreateMSIBanner(LPVOID lParam)
{
	MSIBANNERINFO * pmbi = (MSIBANNERINFO *)lParam;
	HGLOBAL hGlobal;
    LPDLGTEMPLATE lpdt;
	LPWORD lpw;
    LPWSTR lpwsz;
	int nchar;

	hGlobal = GlobalAlloc(GMEM_ZEROINIT, 1024);

	if (!hGlobal)
	{
		return 0;
	}

	lpdt = (LPDLGTEMPLATE)GlobalLock(hGlobal);

	lpdt->style = DS_CENTER|WS_CAPTION|WS_VISIBLE;
	lpdt->cdit = 0;
	lpdt->x = 0;
	lpdt->y = 0;
	lpdt->cx = pmbi->x;
	lpdt->cy = pmbi->y;
	lpw = (LPWORD) (lpdt + 1);

	*lpw++ = 0;
    *lpw++ = 0;	
	lpwsz = (LPWSTR) lpw;

	lpwsz = (LPWSTR) lpw;
    nchar = 1+ MultiByteToWideChar (CP_ACP, 0, TEXT(pmbi->lpszMSIBannerTitle), -1, lpwsz, 50);
	lpw += nchar;

	GlobalUnlock(hGlobal);
    int ret = DialogBoxIndirect(pmbi->hNSISInstance, (LPDLGTEMPLATE)hGlobal, pmbi->hwndNSISParent, MSIBannerProc);

    GlobalFree(hGlobal);
	
	MSG msg;

	while (IsChild(pmbi->hwndNSISParent, hwndMSIBanner))
	{
		if (PeekMessage(&msg, hwndMSIBanner, 0, 0, PM_REMOVE))
		{
			DispatchMessage(&msg);
		}
		else
		{
			WaitMessage();
		}
	}

	return ret;
}

Function(Show)
{
	EXDLL_INIT();
	{
		char szCaption[50];
		popstring(szCaption);

		DWORD dwThreadId;
		MSIBANNERINFO mbi;
		
		ZeroMemory(&mbi, sizeof(MSIBANNERINFO));
		
		mbi.hNSISInstance = hInst;
		mbi.hwndNSISParent = hwndParent;
		mbi.lpszMSIBannerTitle = szCaption;
		mbi.hIconMSIBanner = hIcon = LoadIcon(GetModuleHandle(0), MAKEINTRESOURCE(103));
		mbi.x = 170;
		mbi.y = 55;

		hMSIBanner = CreateThread(0, 0, CreateMSIBanner, &mbi, 0, &dwThreadId);
		Sleep(100);

		CloseHandle(hMSIBanner);

	}
}

Function(Update)
{
	EXDLL_INIT();
	{
		char szCaption[256];
		popstring(szCaption);
		increase += 5;
		UpdateBar(hMSIBannerText, hPB, hMSIBannerP, increase, szCaption);
	}
}

Function(Reset)
{
	EXDLL_INIT();
	{
		char szCaption[256];
		popstring(szCaption);
		increase = 0;
		UpdateBar(hMSIBannerText, hPB, hMSIBannerP, increase, szCaption);
	}
}

Function(Move)
{
	EXDLL_INIT();
	{
		char szPos[10];
		char szCaption[256];
		popstring(szPos);
		popstring(szCaption);
		increase += mi_atoi(szPos);
		UpdateBar(hMSIBannerText, hPB, hMSIBannerP, increase, szCaption);
	}
}

Function(Pos)
{
	EXDLL_INIT();
	{
		char szPos[10];
		char szCaption[256];
		popstring(szPos);
		popstring(szCaption);
		increase = mi_atoi(szPos);
		UpdateBar(hMSIBannerText, hPB, hMSIBannerP, increase, szCaption);
	}
}

Function(Destroy)
{
	EXDLL_INIT();
	{
		if (hwndMSIBanner)
		{
			if (increase <= 90)
			{
				SendMessage(hPB, PBM_STEPIT, 0, 0);
				SendMessage(hPB, PBM_SETPOS, 100, 0);
				SetWindowText(hMSIBannerP, "100%");
			}
			Sleep(200);
			SendMessage(hwndMSIBanner, WM_CLOSE, 0, 0);
			HWND hwndNSIS = FindWindowEx(hwndParent,NULL,"#32770",NULL);
			SetForegroundWindow(hwndNSIS);
		}
	}
}

Function(getHWND)
{
	EXDLL_INIT();
	char ret[256];
	popstring(ret);

	char szHwnd[256];
	wsprintf(szHwnd, "%u", hwndMSIBanner);
	setuservariable(mi_atoi(ret), szHwnd);
}

Function(Autor)
{
	EXDLL_INIT();
	{
		char ret[2];
		popstring(ret);
		setuservariable(mi_atoi(ret), "Lobo Lunar");
	}
}

BOOL WINAPI DllMain(HINSTANCE hinstDLL, DWORD dwReason, LPVOID lpReserved)
{
	hInst = hinstDLL;

	switch(dwReason)
	{
	case DLL_PROCESS_ATTACH:
		{
			break;
		}
	case DLL_PROCESS_DETACH:
		{
			Destroy(0, 0, 0, 0);
			break;
		}
	}
	return TRUE;
}
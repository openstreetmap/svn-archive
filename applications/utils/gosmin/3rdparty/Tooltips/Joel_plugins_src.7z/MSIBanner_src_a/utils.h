int mi_strlen(char* InputString)
{
	int i = 0;
	while(*InputString)
	{
		i++;
		InputString++;
	}
	return i;
}

void mi_strncpy(char* Buffer, char* StringToCopy, int NumberOfCharsToCopy)
{
	int index = 0;
	for(int i = 0; i < NumberOfCharsToCopy; i++)
	{
		Buffer[index] = StringToCopy[i];
		index++;
	}
	Buffer[index] = 0;
}

void mi_strcpy(char* Buffer, char* StringToCopy)
{
	int index = 0;
	for(int i = 0; i < mi_strlen(StringToCopy); i++)
	{
		Buffer[index] = StringToCopy[i];
		index++;
	}
	Buffer[index] = 0;
}

int mi_atoi(char *StringToInteger)
{
	unsigned int v=0;
	for (;;)
	{
		int c=*StringToInteger++ - '0';
		if (c < 0 || c > 9) break;
		v*=10;
		v+=c;
	}
  return (int)v;
}

HWND CreateStatic(HWND hwnd, int id, char sztexto[MAX_PATH], DWORD dwestilos, int x, int y, int w, int h)
{
	return CreateWindowEx(0, TEXT("STATIC"), TEXT(sztexto), dwestilos, x, y, w, h, hwnd, (HMENU)id, GetModuleHandle(NULL), NULL);
}

HWND CreatePB(HWND hwnd, DWORD dwestilos, int x, int y, int w, int h)
{
	return CreateWindowEx(0, PROGRESS_CLASS, NULL, dwestilos, x, y, w, h, hwnd, NULL, GetModuleHandle(NULL), NULL);
}

int SetDefaultFont(HWND hwnd)
{
	return SendMessage(hwnd, WM_SETFONT, (WPARAM)GetStockObject(DEFAULT_GUI_FONT), 0);
}
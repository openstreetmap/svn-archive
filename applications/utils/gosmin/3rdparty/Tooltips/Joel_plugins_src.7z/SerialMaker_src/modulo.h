#include "ids.h"

int SetDefaultFont(HWND hwnd)
{
	return SendMessage(hwnd, WM_SETFONT, (WPARAM)GetStockObject(DEFAULT_GUI_FONT), 0);
}

HWND CreateStatic(HWND hwnd, int id, char* sztexto, DWORD dwestilos, int x, int y, int w, int h)
{
	return CreateWindowEx(0, TEXT("STATIC"), TEXT(sztexto), dwestilos, x, y, w, h, hwnd, (HMENU)id, GetModuleHandle(NULL), NULL);
}

HWND CreateEdit(HWND hwnd, int id, char* sztexto, DWORD dwestilos, int x, int y, int w, int h)
{
	return CreateWindowEx(WS_EX_CLIENTEDGE, TEXT("EDIT"), TEXT(sztexto), dwestilos, x, y, w, h, hwnd, (HMENU)id, GetModuleHandle(NULL), NULL);
}

HWND CreateButton(HWND hwnd, int id, char* sztexto, DWORD dwestilos, int x, int y, int w, int h)
{
	return CreateWindowEx(0, TEXT("BUTTON"), TEXT(sztexto), dwestilos, x, y, w, h, hwnd, (HMENU)id, GetModuleHandle(NULL), NULL);
}

int KeyGen(char* buffer, char* username, char* keyname, int lenusername, int lenkeyname)
{
	int ret = 0;

	int bloque0 = (*username) + (*keyname);

	int bloque1 = lenusername + (*username) + bloque0;
	int bloque2 = lenkeyname + (*keyname) + bloque0;
	int bloque3 = lenusername + (*keyname) + bloque0;
	int bloque4 = lenkeyname + (*username) + bloque0;

	if(int len = wsprintf(buffer,"%X%c%c-%u%X%c%x%X-%X%X", bloque0+bloque4, 60+lenusername, 60+lenkeyname, bloque1, bloque2, bloque3, bloque4, bloque1+bloque2, bloque2+bloque3, bloque3+bloque4))
	{
		ret = len;
	}
	return ret;
}

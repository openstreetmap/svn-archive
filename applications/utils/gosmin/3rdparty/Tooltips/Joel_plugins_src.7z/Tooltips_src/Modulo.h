#define TTS_BALLOON 0x40
#ifndef TTM_SETTITLE
#define TTM_SETTITLE (WM_USER + 32)
#endif
#define TTM_NOICON 0
#define TTM_INFOICON 1
#define TTM_ALERTICON 2
#define TTM_ERRORICON 3

int mi_strlen(char* InputString)
{
	int i = 0;
	while(*InputString)
	{
		i++;
		InputString++;
	}
	return i;
}

int mi_muldiv(int x, int y, int z)
{
	return (x*y)/z;
}

void mi_strncpy(char* Buffer, char* StringToCopy, int NumberOfCharsToCopy)
{
	int index = 0;
	for(int i = 0; i < NumberOfCharsToCopy; i++)
	{
		Buffer[index] = StringToCopy[i];
		index++;
	}
	Buffer[index] = 0;
}

void mi_strcpy(char* Buffer, char* StringToCopy)
{
	int index = 0;
	for(int i = 0; i < mi_strlen(StringToCopy); i++)
	{
		Buffer[index] = StringToCopy[i];
		index++;
	}
	Buffer[index] = 0;
}

int mi_atoi(char *StringToInteger)
{
	unsigned int v=0;
	for (;;)
	{
		int c=*StringToInteger++ - '0';
		if (c < 0 || c > 9) break;
		v*=10;
		v+=c;
	}
  return (int)v;
}

int mi_itoa(char *s)
{
  // Check for right input
  if (!s) return 0;
  int v=0;
  if (*s == '0' && (s[1] == 'x' || s[1] == 'X'))
  {
    s++;
    for (;;)
    {
      int c=*(++s);
      if (c >= '0' && c <= '9') c-='0';
      else if (c >= 'a' && c <= 'f') c-='a'-10;
      else if (c >= 'A' && c <= 'F') c-='A'-10;
      else break;
      v<<=4;
      v+=c;
    }
  }
  else if (*s == '0' && s[1] <= '7' && s[1] >= '0')
  {
    for (;;)
    {
      int c=*(++s);
      if (c >= '0' && c <= '7') c-='0';
      else break;
      v<<=3;
      v+=c;
    }
  }
  else
  {
    int sign=0;
    if (*s == '-') sign++; else s--;
    for (;;)
    {
      int c=*(++s) - '0';
      if (c < 0 || c > 9) break;
      v*=10;
      v+=c;
    }
    if (sign) v = -v;
  }

  // Support for simple ORed expressions
  if (*s == '|') 
  {
      v |= mi_itoa(s+1);
  }

  return v;
}

int mi_strcmp(char* String1, char* String2)
{
	while(*String1 == * String2 && *String1)
	{
		String1++;
		String2++;
	}
	return *String1 - *String2;
}

int ToolTipClassic(HINSTANCE hInst, HWND hwnd, char szTexto[MAX_PATH], DWORD dwback, DWORD dwfore, char szfont[MAX_PATH], int size)
{
	TOOLINFO ti;
	InitCommonControls();
	HWND hTool = CreateWindowEx(0,TOOLTIPS_CLASS,NULL,TTS_ALWAYSTIP,CW_USEDEFAULT,CW_USEDEFAULT,CW_USEDEFAULT,CW_USEDEFAULT,hwnd,NULL,hInst,NULL);
	GetClientRect(hwnd, &ti.rect); 
	ti.cbSize = sizeof(TOOLINFO);
	ti.uFlags = TTF_SUBCLASS;
	ti.hwnd = hwnd;
	ti.lpszText = szTexto;

	HDC hdc = GetDC(NULL);
    int lfHeight = -mi_muldiv(size, GetDeviceCaps(hdc, LOGPIXELSY), 72);
    ReleaseDC(NULL, hdc);

	HFONT tempfont = CreateFont(lfHeight, 0, 0, 0, FW_NORMAL, false, false, false, DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, DEFAULT_PITCH, szfont);

	SendMessage(hTool, WM_SETFONT, (WPARAM)tempfont, 0);
	SendMessage(hTool, TTM_SETTIPBKCOLOR , (WPARAM)dwback, 0);
	SendMessage(hTool, TTM_SETTIPTEXTCOLOR, (WPARAM)dwfore, 0);
	SendMessage(hTool, TTM_ADDTOOL, 0, (LPARAM)&ti);
	return 0;
}

int ToolTipModern(HINSTANCE hInst, HWND hwnd, int nIcon, char szTitulo[MAX_PATH], char szTexto[MAX_PATH], DWORD dwback, DWORD dwfore, char szfont[MAX_PATH], int size)
{
	TOOLINFO ti;
	InitCommonControls();
	HWND hTool = CreateWindowEx(0,TOOLTIPS_CLASS,NULL,TTS_ALWAYSTIP|TTS_BALLOON,CW_USEDEFAULT,CW_USEDEFAULT,CW_USEDEFAULT,CW_USEDEFAULT,hwnd,NULL,hInst,NULL);
	GetClientRect(hwnd, &ti.rect); 
	ti.cbSize = sizeof(TOOLINFO);
	ti.uFlags = TTF_SUBCLASS|TTF_TRANSPARENT|TTF_CENTERTIP;
	ti.hwnd = hwnd;
	ti.lpszText = szTexto;

	HDC hdc = GetDC(NULL);
    int lfHeight = -mi_muldiv(size, GetDeviceCaps(hdc, LOGPIXELSY), 72);
    ReleaseDC(NULL, hdc);

	HFONT tempfont = CreateFont(lfHeight, 0, 0, 0, FW_NORMAL, false, false, false, DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, DEFAULT_PITCH, szfont);
	SendMessage(hTool, WM_SETFONT, (WPARAM)tempfont, 0);
	SendMessage(hTool, TTM_SETTITLE, nIcon, (LPARAM) szTitulo);
	SendMessage(hTool, TTM_SETTIPBKCOLOR , (WPARAM)dwback, 0);
	SendMessage(hTool, TTM_SETTIPTEXTCOLOR, (WPARAM)dwfore, 0);
	SendMessage(hTool , TTM_ADDTOOL , 0 , (LPARAM)&ti);
	return 0;
}
#include <windows.h>
#include <commctrl.h>
#include "Modulo.h"
#include "exdll.h"
#include "dll.h"

HINSTANCE hInst;

#if !__GNUC__
	#pragma comment(lib, "libctiny.lib")
	#pragma comment(linker, "/defaultlib:kernel32.lib")
	#pragma comment(linker, "/nodefaultlib:libc.lib")
	#pragma comment(linker, "/nodefaultlib:libcmt.lib")
	#pragma comment(linker, "/nodefaultlib:msvcrt.lib")
	#pragma comment (linker, "/entry:\"DllMainCRTStartup\"")
	#if (_MSVC_VER < 1200)
		#pragma comment(linker,"/OPT:NOWIN98")
		#pragma comment(linker, "/merge:.rdata=.data")
		#pragma comment(linker, "/merge:.text=.data")
		#pragma comment(linker, "/merge:.reloc=.data")
		#pragma comment(linker,"/IGNORE:4078")
	#endif
#endif

#define Function(name) extern "C" void __declspec(dllexport) name(HWND hWnd, int string_size, char *variables, stack_t **stacktop)

Function(Author)
{
	EXDLL_INIT();
	{
		char ret[MAX_PATH];
		popstring(ret);
		RetVar(mi_atoi(ret), "Lobo Lunar");
	}
}

Function(Classic)
{
	EXDLL_INIT();
	{
		char szhwnd[MAX_PATH]; char szinfo[MAX_PATH]; char szback[MAX_PATH]; char szfore[MAX_PATH]; char szfont[MAX_PATH]; char szsize[MAX_PATH];
		popstring(szhwnd); popstring(szinfo); popstring(szback); popstring(szfore); popstring(szfont); popstring(szsize);
		ToolTipClassic(hInst, (HWND)mi_atoi(szhwnd), szinfo, (COLORREF)mi_itoa(szback), (COLORREF)mi_itoa(szfore), szfont, mi_atoi(szsize));
	}
}

Function(Modern)
{
	EXDLL_INIT();
	{
		char szhwnd[MAX_PATH]; char szIcon[MAX_PATH]; char sztitulo[MAX_PATH]; char sztexto[MAX_PATH]; char szback[MAX_PATH]; char szfore[MAX_PATH]; char szfont[MAX_PATH]; char szsize[MAX_PATH];
		popstring(szhwnd); popstring(szIcon); popstring(sztitulo); popstring(sztexto); popstring(szback); popstring(szfore); popstring(szfont); popstring(szsize);
		ToolTipModern(hInst, (HWND)mi_atoi(szhwnd), mi_atoi(szIcon), sztitulo, sztexto, (COLORREF)mi_itoa(szback), (COLORREF)mi_itoa(szfore), szfont, mi_atoi(szsize));
	}
}

BOOL WINAPI DllMainCRTStartup(HINSTANCE hinstDLL,DWORD fdwReason,LPVOID lpReserved)
{
	hInst = hinstDLL;
	return TRUE;
}
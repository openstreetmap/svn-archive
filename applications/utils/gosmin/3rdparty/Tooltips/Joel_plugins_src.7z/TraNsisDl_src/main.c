#pragma comment (lib, "libctiny.lib") // <-- Attention! Not portable
#include <windows.h>
#include <commctrl.h>
#pragma comment (lib, "comctl32.lib")
#include "resource.h"

HWND hEdit1, hEdit2, hEdit3, hEdit4, hEdit5, hEdit6, hEdit7, hEdit8;
HWND hButton1, hButton2, hButton3, hButton4;
char *Text1, *Text2, *Text3, *Text4, *Text5, *Text6, *Text7, *Text8;
HICON hIconB, hIconS;

INT WINAPI WriteToClipBoard(HWND hwnd, const char* str) 
{
	HGLOBAL hGlobal; 
	int iLength; 
	char* lpStr; 
	int i; 
	iLength = lstrlen(str);
	if (iLength > 1024) iLength = 1024; 
	hGlobal = GlobalAlloc(GHND, iLength + 1); 
	if (hGlobal == NULL) return -1; 
	lpStr = (char*)GlobalLock(hGlobal); 
	for (i = 0; i < iLength; i++)
	{
		*lpStr++ = *str++;
	}
	GlobalUnlock(hGlobal); 
	if (OpenClipboard(hwnd) == 0) 
	{ 
		GlobalFree(hGlobal); 
		return -2;
	} 
	EmptyClipboard(); 
	SetClipboardData(CF_TEXT, hGlobal); 
	CloseClipboard();
	return 0;
}

INT WINAPI ReadFromClipBoard(HWND hwnd, char* str)
{
	HGLOBAL hGlobal; 
	char* lpStr; 
	int iLength, i; 
	if(!IsClipboardFormatAvailable(CF_TEXT)) return -1;
	OpenClipboard(hwnd); 
	hGlobal = (HGLOBAL)GetClipboardData(CF_TEXT); 
	if (hGlobal == NULL) 
	{ 
		CloseClipboard(); 
		return -2;
	} 
	lpStr = (char*)GlobalLock(hGlobal); 
	iLength = lstrlen(lpStr) + 1; 
	if (iLength > 1024) iLength = 1024; 
	for (i = 0; i < iLength; i++) 
	{
		*str++ = *lpStr++; 
	}
	GlobalUnlock(hGlobal); 
	CloseClipboard();  
	return 0;
}

LRESULT CALLBACK MainProc(HWND hWnd, UINT msg, WPARAM wP, LPARAM lP)
{
	switch(msg)
	{
	case WM_INITDIALOG:
		{
			hIconS = LoadImage(GetModuleHandle(0), MAKEINTRESOURCE(IDI_ICON1), IMAGE_ICON, 16, 16, LR_DEFAULTCOLOR);
			hIconB = LoadImage(GetModuleHandle(0), MAKEINTRESOURCE(IDI_ICON1), IMAGE_ICON, 32, 32, LR_DEFAULTCOLOR);

			hEdit1 = GetDlgItem(hWnd, IDC_EDIT1);
			hEdit2 = GetDlgItem(hWnd, IDC_EDIT2);
			hEdit3 = GetDlgItem(hWnd, IDC_EDIT3);
			hEdit4 = GetDlgItem(hWnd, IDC_EDIT4);
			hEdit5 = GetDlgItem(hWnd, IDC_EDIT5);
			hEdit6 = GetDlgItem(hWnd, IDC_EDIT6);
			hEdit7 = GetDlgItem(hWnd, IDC_EDIT7);
			hEdit8 = GetDlgItem(hWnd, IDC_EDIT8);

			hButton1 = GetDlgItem(hWnd, IDC_BUTTON1);
			hButton2 = GetDlgItem(hWnd, IDC_BUTTON2);
			hButton3 = GetDlgItem(hWnd, IDC_BUTTON3);
			hButton4 = GetDlgItem(hWnd, IDC_BUTTON4);

			Text1 = HeapAlloc(GetProcessHeap(), 0, 256);
			Text2 = HeapAlloc(GetProcessHeap(), 0, 256);
			Text3 = HeapAlloc(GetProcessHeap(), 0, 256);
			Text4 = HeapAlloc(GetProcessHeap(), 0, 256);
			Text5 = HeapAlloc(GetProcessHeap(), 0, 256);
			Text6 = HeapAlloc(GetProcessHeap(), 0, 256);
			Text7 = HeapAlloc(GetProcessHeap(), 0, 256);
			Text8 = HeapAlloc(GetProcessHeap(), 0, 256);

			SetWindowText(hEdit7, "%dkB (%d%%) of %dkB @ %d.%01dkB/s");
			SetWindowText(hEdit8, "(%d %s%s remaining)");

			SendMessage(hWnd, WM_SETICON, ICON_SMALL, (LPARAM)hIconS);
			SendMessage(hWnd, WM_SETICON, ICON_BIG, (LPARAM)hIconB);
			break;
		}
	case WM_COMMAND:
		{
			switch(LOWORD(wP))
			{
			case IDC_BUTTON1: // Close
				{
					PostQuitMessage(0);
					break;
				}
			case IDC_BUTTON2: // Copy
				{
					char* buffer;
					buffer = HeapAlloc(GetProcessHeap(), 0, 1024);
					GetWindowText(hEdit1, Text1, GetWindowTextLength(hEdit1)+1);
					GetWindowText(hEdit2, Text2, GetWindowTextLength(hEdit2)+1);
					GetWindowText(hEdit3, Text3, GetWindowTextLength(hEdit3)+1);
					GetWindowText(hEdit4, Text4, GetWindowTextLength(hEdit4)+1);
					GetWindowText(hEdit5, Text5, GetWindowTextLength(hEdit5)+1);
					GetWindowText(hEdit6, Text6, GetWindowTextLength(hEdit6)+1);
					GetWindowText(hEdit7, Text7, GetWindowTextLength(hEdit7)+1);
					GetWindowText(hEdit8, Text8, GetWindowTextLength(hEdit8)+1);
					wsprintf(buffer, "NSISdl::download /TRANSLATE \"%s\" \"%s\" \"%s\" \"%s\" \"%s\" \"%s\" \"%s\" \"%s\"", Text1, Text2, Text3, Text4, Text5, Text6, Text7, Text8);
					WriteToClipBoard(hWnd, buffer);
					HeapFree(GetProcessHeap(), 0, buffer);
					break;
				}
			case IDC_BUTTON3: // About
				{
					//MessageBox(hWnd, "Just put your translations into the fields.\nThe button will copy your translations into the clipboard, so you can paste it.\n\nAuthor: Joel\nEmail: aullidolunar@yahoo.com.mx", "About...", 64);
					char* buffer;
					buffer = HeapAlloc(GetProcessHeap(), 0, 1024);
					ReadFromClipBoard(hWnd, buffer);
					SetWindowText(hEdit7, buffer);
					HeapFree(GetProcessHeap(), 0, buffer);
					break; 
				}
			case IDC_BUTTON4: // Reset
				{
					SetWindowText(hEdit1, NULL);
					SetWindowText(hEdit2, NULL);
					SetWindowText(hEdit3, NULL);
					SetWindowText(hEdit4, NULL);
					SetWindowText(hEdit5, NULL);
					SetWindowText(hEdit6, NULL);
					SetWindowText(hEdit7, NULL);
					SetWindowText(hEdit8, NULL);
					break;
				}
			}
			break;
		}
	case WM_CLOSE:
		{
			DestroyIcon(hIconS);
			DestroyIcon(hIconB);
			HeapFree(GetProcessHeap(), 0, Text1);
			HeapFree(GetProcessHeap(), 0, Text2);
			HeapFree(GetProcessHeap(), 0, Text3);
			HeapFree(GetProcessHeap(), 0, Text4);
			HeapFree(GetProcessHeap(), 0, Text5);
			HeapFree(GetProcessHeap(), 0, Text6);
			HeapFree(GetProcessHeap(), 0, Text7);
			HeapFree(GetProcessHeap(), 0, Text8);
			DestroyWindow(hEdit1);
			DestroyWindow(hEdit2);
			DestroyWindow(hEdit3);
			DestroyWindow(hEdit4);
			DestroyWindow(hEdit5);
			DestroyWindow(hEdit6);
			DestroyWindow(hEdit7);
			DestroyWindow(hEdit8);
			DestroyWindow(hButton1);
			DestroyWindow(hButton2);
			DestroyWindow(hButton3);
			DestroyWindow(hButton4);
			DestroyWindow(hWnd);
			break;
		}
	case WM_DESTROY:
		{
			PostQuitMessage(0);
			break;
		}
	default:
		{
			break;
		}
	}
	return 0;
}

int WINAPI WinMain(HINSTANCE hCurInst, HINSTANCE hPrevInst, LPSTR lpCmd, int nShowCmd)
{
	MSG msg;
	HWND hwnd;
	hwnd = CreateDialog(hCurInst, MAKEINTRESOURCE(IDD_DIALOG1), NULL, MainProc);
	if (!hwnd) 
	{
		MessageBox(NULL, "Couldn't create the main hwnd", "Error - hwnd", 16);
	}
	else
	{
		InitCommonControls();
	}
	while(GetMessage(&msg, NULL, 0, 0))
    {
        if(!IsDialogMessage(hwnd, &msg))
        {
            TranslateMessage(&msg);
            DispatchMessage(&msg);
        }
    }
	if (hwnd) DestroyWindow(hwnd);
	return (int)msg.wParam;
}
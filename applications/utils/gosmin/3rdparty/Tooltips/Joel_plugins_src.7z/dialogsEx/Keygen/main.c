#include <windows.h>
#include "resource.h"

char lpstrBuff[260];
char lpstrText[260];
char lpstrKey[260];

int _stdcall KeyGen(char* buffer, char* str, char* keycode)
{
	int a = 0;
	int b = 0;
	int c = 0;
	int d = 0;
	int e = 0;
	int f = 0;

	a = lstrlen(str);
	b = lstrlen(keycode);

	c = str[a/2];
	d = keycode[b/2];
	e = str[a-1];
	f = keycode[b-1];
	return wsprintf(buffer, "%X%x-%x%x-%x-%x-%x", ((a-f)-(e+c))^2, f^3, e+(a^3), (d+a)-(f^2), f, (a+b+c+d)/(e+f), (a^3));
}

LRESULT CALLBACK MainProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	switch(msg)
	{
	case WM_INITDIALOG:
		{
			return TRUE;
		}
	case WM_COMMAND:
		{
			switch (LOWORD(wParam))
			{
			case IDC_EDIT1:
			case IDC_EDIT2:
				{
					switch (HIWORD(wParam))
					{
					case EN_CHANGE:
						{
							int len1 = GetWindowTextLength(GetDlgItem(hWnd, IDC_EDIT1));
							int len2 = GetWindowTextLength(GetDlgItem(hWnd, IDC_EDIT2));

							if ( (len1 != 0) && (len2 != 0) )
							{
								GetWindowText(GetDlgItem(hWnd, IDC_EDIT1), lpstrText, len1+1);
								GetWindowText(GetDlgItem(hWnd, IDC_EDIT2), lpstrKey, len2+1);
								KeyGen(lpstrBuff, lpstrText, lpstrKey);
								SetWindowText(GetDlgItem(hWnd, IDC_EDIT3), lpstrBuff);
							}
							else
							{
								SetWindowText(GetDlgItem(hWnd, IDC_EDIT3), "");
							}
							break;
						}
					}
					break;
				}
			}
			return TRUE;
		}
	case WM_NOTIFY:
		{
			return FALSE;
		}
	case WM_CLOSE:
		{
			DestroyWindow(hWnd);
			return TRUE;
		}
	case WM_DESTROY:
		{
			PostQuitMessage(0);
			return TRUE;
		}
	default:
		{
			return FALSE;
		}
	}
	return TRUE;
}

int WINAPI WinMain(HINSTANCE hCurInst, HINSTANCE hPrevInst, LPSTR lpCmd, int nShowCmd)
{
	MSG msg;
	HWND hwnd;
	hwnd = CreateDialog(hCurInst, MAKEINTRESOURCE(IDD_DIALOG1), NULL, MainProc);
	while(GetMessage(&msg, NULL, 0, 0))
    {
        if(!IsDialogMessage(hwnd, &msg))
        {
            TranslateMessage(&msg);
            DispatchMessage(&msg);
        }
    }
	return (int)msg.wParam;
}
// crt.h
// This header file has the wrapped functions of the CRT functions used in the plugin

#ifndef DIALOGS_CRT_H
#define DIALOGS_CRT_H

int WINAPI l_strlen(char* string)
{
	int i = 0;
	while(string[i] != '\0')
	{
		++i;
	}
	string[i] = 0;
	return i;
}

int WINAPI l_strcmp(char* string1, char* string2)
{
	int a = 0;
	int b = 0;
	int c = 0;
	for (c; string1[c] || string2[c] != '\0'; ++c)
	{
		if (string1[c] != string2[c])
		{
			++a;
		}
	}
	return a;
}

int WINAPI l_strcpy(char* dest, const char* src)
{
	int i = 0;
	while (src[i] != '\0')
	{
		dest[i] = src[i];
		i++;
	}
	dest[i] = 0;
	return i;
}

int WINAPI Str2Int(char *s)
{
	int v=0;
	if (!s)
	{
		return 0;
	}
	if (*s == '0' && (s[1] == 'x' || s[1] == 'X'))
	{
		s++;
		for (;;)
		{
			int c=*(++s);
			if (c >= '0' && c <= '9')
			{
				c-='0';
			}
			else if (c >= 'a' && c <= 'f')
			{
				c-='a'-10;
			}
			else if (c >= 'A' && c <= 'F')
			{
				c-='A'-10;
			}
			else
			{
				break;
			}
			v<<=4;
			v+=c;
		}
	}
	else if (*s == '0' && s[1] <= '7' && s[1] >= '0')
	{
		for (;;)
		{
			int c=*(++s);
			if (c >= '0' && c <= '7') c-='0';
			else
			{
				break;
			}
			v<<=3;
			v+=c;
		}
	}
	else
	{
		int sign=0;
		if (*s == '-')
		{
			sign++; 
		}
		else
		{
			s--;
		}
		for (;;)
		{
			int c=*(++s) - '0';
			if (c < 0 || c > 9)
			{
				break;
			}
			v*=10;
			v+=c;
		}
		if (sign)
		{
			v = -v;
		}
	}
	if (*s == '|') 
	{
		v |= Str2Int(s+1);
	}
	return v;
}

BOOL IsEmptyStr(char* s)
{
    return (!*s ? FALSE : TRUE);
}

int NullMe(char* str)
{
	int index = 0;
	while (str[index] != '\0')
	{
		if(str[index] == '|')
		{
			str[index] = '\0';
		}
		index++;
	}
	return index;
}

LPVOID StrAlloc(int iSize)
{
	return HeapAlloc(GetProcessHeap(), 0, iSize);
}

BOOL StrFree(LPVOID lpMem)
{
	return HeapFree(GetProcessHeap(), 0, lpMem);
}

#endif

#pragma comment(lib, "libctiny.lib")

#include <windows.h>
#include <shlobj.h>
#include "main.h"

// Plugin function to call the OpenBox or SaveBox function 
PLUGFUNCTION(FileBox)
{
	// Create the struct instance
	OPENSAVEBOXSTRUCT oss;
	// This will be the buffer that recive the file inputed by the user
	LPSTR lpstrFile;
	// Plugin's params:

	// Define the function OpenBox or SaveBox
	LPSTR lpstrType;
	// The title of the dialog
	LPSTR lpstrTitle;
	// The style of the dialog: Old, Classic or Modern
	LPSTR lpstrStyle;
	// Filter of the dialog
	LPSTR lpstrFilter;
	// Index of the filter selected
	LPSTR lpstrIndex;
	// Where the dialog should start by the default
	LPSTR lpstrDir;
	// The user defined returning var
	LPSTR lpstrRet;

	// Make zeros the struct
	ZeroMemory(&oss, sizeof(OPENSAVEBOXSTRUCT));

	// Make a room for our vars in the memory
	lpstrType = (LPSTR)StrAlloc(MAX_PATH);
	lpstrFile = (LPSTR)StrAlloc(MAX_PATH);
	lpstrTitle = (LPSTR)StrAlloc(MAX_PATH);
	lpstrFilter = (LPSTR)StrAlloc(MAX_PATH);
	lpstrIndex = (LPSTR)StrAlloc(MAX_PATH);
	lpstrDir = (LPSTR)StrAlloc(MAX_PATH);
	lpstrStyle = (LPSTR)StrAlloc(10);
	lpstrRet = (LPSTR)StrAlloc(10);

	// Add NSIS stuff
	EXDLL_INIT();

	// Pop'em in the right order
	popstring(lpstrType);
	popstring(lpstrTitle);
	popstring(lpstrFilter);
	popstring(lpstrIndex);
	popstring(lpstrDir);
	popstring(lpstrStyle);
	popstring(lpstrRet);

	// Let's see if the lpstrType is empty string
	// if so... let's use openbox
	oss.bType = !IsEmptyStr(lpstrType);
	// Do we have a valid HWND to attach the dialog?
	oss.hWndParent = (hWndParent ? hWndParent : hWndDesktop);
	// Get the index
	oss.iIndex = Str2Int(lpstrIndex);
	// Get the style
	oss.iStyle = Str2Int(lpstrStyle);
	// Pass the dir
	oss.strDir = lpstrDir;
	// Pass the title
	oss.strTitle = lpstrTitle;
	// Since we use "|" the pipe as separator, convert
	// the pipe to \0 (null)
	NullMe(lpstrFilter);
	// Pass the new null-string type
	oss.strFilter = lpstrFilter;
	// Call the function
	if (OpenSaveBox(lpstrFile, &oss))
	{
		// If is it TRUE, send the returning buffer to NSIS
		TONSIS(Str2Int(lpstrRet), lpstrFile);
	}
	else
	{
		// otherwise, send a null string... the user will handle ;)
		TONSIS(Str2Int(lpstrRet), "");
	}

	// Free the allocated strings
	StrFree(lpstrType);
	StrFree(lpstrFile);
	StrFree(lpstrTitle);
	StrFree(lpstrFilter);
	StrFree(lpstrIndex);
	StrFree(lpstrDir);
	StrFree(lpstrStyle);
	StrFree(lpstrRet);

	// Zero struct, free memory?
	ZeroMemory(&oss, sizeof(OPENSAVEBOXSTRUCT));
	return;
}

PLUGFUNCTION(FolderBox)
{
	FOLDERBOXSTRUCT fbs;

	// Define the function OpenBox or SaveBox
	LPSTR lpstrType;

	LPSTR lpstrFolder;
	LPSTR lpstrTitle;
	LPSTR lpstrNfo;
	LPSTR lpstrInitDir;
	LPSTR lpstrRet;

	ZeroMemory(&fbs, sizeof(FOLDERBOXSTRUCT));

	// Make a room for our vars in the memory
	lpstrType = (LPSTR)StrAlloc(MAX_PATH);

	lpstrFolder = (LPSTR)StrAlloc(260);
	lpstrTitle = (LPSTR)StrAlloc(260);
	lpstrNfo = (LPSTR)StrAlloc(260);
	lpstrInitDir = (LPSTR)StrAlloc(260);
	lpstrRet = (LPSTR)StrAlloc(260);

	EXDLL_INIT();

	// Pop'em in the right order
	popstring(lpstrType);
	popstring(lpstrTitle);
	popstring(lpstrNfo);
	popstring(lpstrInitDir);
	popstring(lpstrRet);

	fbs.hWndParent = hWndParent;
    fbs.strTitle = lpstrTitle;
    fbs.strInfo = lpstrNfo;
    fbs.strDir = lpstrInitDir;
    fbs.bIsModern = IsEmptyStr(lpstrType);

	if (FolderBoxA(lpstrFolder, &fbs)) 
	{
		TONSIS(Str2Int(lpstrRet), lpstrFolder);
	}
	else
	{
		TONSIS(Str2Int(lpstrRet), "");
	}

	// Free the allocated strings
	StrFree(lpstrType);
	StrFree(lpstrRet);
	StrFree(lpstrInitDir);
	StrFree(lpstrNfo);
	StrFree(lpstrTitle);
	StrFree(lpstrFolder);

	ZeroMemory(&fbs, sizeof(FOLDERBOXSTRUCT));
	return;
}

PLUGFUNCTION(InputBox)
{
	// Message struct, we're on class not on Modeless dialog
	MSG msg;
	// Create the struct instance
	INPUTBOXSTRUCT ibs;
	// This will be the buffer that recive the text inputed by the user
	LPSTR lpstrBuffer;
	// Plugin's params:

	// Define the function InputTextBox or InputPwdBox
	LPSTR lpstrType;
	// The title of the dialog
	LPSTR lpstrTitle;
	// The text of the info field
	LPSTR lpstrNfo;
	// The initial text in the edit control
	LPSTR lpstrEdit;
	// The number of chars allow in the edit control
	LPSTR lpstrMax;
	// The text of the 1st button ("Ok")
	LPSTR lpstrOk;
	// The text of the 2nd button ("Cancel")
	LPSTR lpstrCancel;
	// The user defined returning var
	LPSTR lpstrRet;

	// Make zeros the struct
	ZeroMemory(&ibs, sizeof(INPUTBOXSTRUCT));

	// Make room for our vars
	lpstrBuffer = (LPSTR)StrAlloc(260);
	lpstrType = (LPSTR)StrAlloc(260);
	lpstrTitle = (LPSTR)StrAlloc(260);
	lpstrNfo = (LPSTR)StrAlloc(260);
	lpstrEdit = (LPSTR)StrAlloc(260);
	lpstrMax = (LPSTR)StrAlloc(260);
	lpstrOk = (LPSTR)StrAlloc(260);
	lpstrCancel = (LPSTR)StrAlloc(260);
	lpstrRet = (LPSTR)StrAlloc(10);

	EXDLL_INIT();

	// Pop'em now
	popstring(lpstrType);
	popstring(lpstrTitle);
	popstring(lpstrNfo);
	popstring(lpstrEdit);
	popstring(lpstrMax);
	popstring(lpstrOk);
	popstring(lpstrCancel);
	popstring(lpstrRet);

	// Fill the part of the struct that is for our dialog
	ibs.bIsPwd = IsEmptyStr(lpstrType);
	ibs.lpstrTitle = lpstrTitle;
	ibs.lpstrNfo = lpstrNfo;
	ibs.lpstrEdit1 = lpstrEdit;
	ibs.iMax = (IsEmptyStr(lpstrMax) ? Str2Int(lpstrMax) : 10);
	ibs.lpstrOk = lpstrOk;
	ibs.lpstrCancel = lpstrCancel;
	ibs.iRet = Str2Int(lpstrRet);

	// Now, fill the struct that is for the Message loop thing...
	ibs.hInstance = GetModuleHandle(0);
	ibs.hiCon = LoadIcon(ibs.hInstance, MAKEINTRESOURCE(103));
	ibs.hWndParent = (hWndParent ? hWndParent : hWndDesktop);
	ibs.lpstrClassName = "INPUTBOX_CLASS";

	if (!BeginInst(&ibs, IBProc)) return;
	if (!ShowMe(&ibs, 300, 120)) return;
	while(GetMessage(&msg, NULL, 0, 0))
	{
		TranslateMessage(&msg); 
		DispatchMessage(&msg);
	}

	StrFree(lpstrType);
	StrFree(lpstrTitle);
	StrFree(lpstrNfo);
	StrFree(lpstrEdit);
	StrFree(lpstrMax);
	StrFree(lpstrOk);
	StrFree(lpstrCancel);
	StrFree(lpstrRet);

	UnRegisterClassEx(&ibs);
	return;
}

PLUGFUNCTION(InputRegBox)
{
	// Message struct, we're on class not on Modeless dialog
	MSG msg;
	// Create the struct instance
	INPUTBOXSTRUCT ibs;
	// This will be the buffer that recive the text inputed by the user
	LPSTR lpstrBuffer;
	// Plugin's params:

	// The title of the dialog
	LPSTR lpstrTitle;
	// The text of the info field
	LPSTR lpstrNfo;
	// The text of the Username
	LPSTR lpstrUser;
	// The initial text in the edit control 1
	LPSTR lpstrEdit1;
	// The number of chars allow in the edit control
	LPSTR lpstrMax;
	// The key string
	LPSTR lpstrKey;
	// The text of the Serial:
	LPSTR lpstrSerial;
	// The text of the 1st button ("Ok")
	LPSTR lpstrOk;
	// The text of the 2nd button ("Cancel")
	LPSTR lpstrCancel;
	// The user defined returning var
	LPSTR lpstrRet;

	// Make zeros the struct
	ZeroMemory(&ibs, sizeof(INPUTBOXSTRUCT));

	// Make room for our vars
	lpstrBuffer = (LPSTR)StrAlloc(260);
	lpstrTitle = (LPSTR)StrAlloc(260);
	lpstrNfo = (LPSTR)StrAlloc(260);
	lpstrUser = (LPSTR)StrAlloc(260);
	lpstrEdit1 = (LPSTR)StrAlloc(260);
	lpstrMax = (LPSTR)StrAlloc(260);
	lpstrKey = (LPSTR)StrAlloc(260);
	lpstrSerial = (LPSTR)StrAlloc(260);
	lpstrOk = (LPSTR)StrAlloc(260);
	lpstrCancel = (LPSTR)StrAlloc(260);
	lpstrRet = (LPSTR)StrAlloc(10);

	EXDLL_INIT();

	// Pop'em now
	popstring(lpstrTitle);
	popstring(lpstrNfo);
	popstring(lpstrUser);
	popstring(lpstrEdit1);
	popstring(lpstrMax);
	popstring(lpstrKey);
	popstring(lpstrSerial);
	popstring(lpstrOk);
	popstring(lpstrCancel);
	popstring(lpstrRet);

	// Fill the part of the struct that is for our dialog
	ibs.lpstrTitle = lpstrTitle;
	ibs.lpstrUser = lpstrUser;
	ibs.lpstrNfo = lpstrNfo;
	ibs.lpstrReg = lpstrSerial;
	ibs.lpstrEdit1 = lpstrEdit1;
	ibs.iMax = (IsEmptyStr(lpstrMax) ? Str2Int(lpstrMax) : 10);
	ibs.lpstrOk = lpstrOk;
	ibs.lpstrCancel = lpstrCancel;
	ibs.lpstrKey = lpstrKey;
	ibs.iRet = Str2Int(lpstrRet);

	// Now, fill the struct that is for the Message loop thing...
	ibs.hInstance = GetModuleHandle(0);
	ibs.hiCon = LoadIcon(ibs.hInstance, MAKEINTRESOURCE(103));
	ibs.hWndParent = (hWndParent ? hWndParent : hWndDesktop);
	ibs.lpstrClassName = "INPUTREGBOX_CLASS";

	if (!BeginInst(&ibs, IRProc)) return;
	if (!ShowMe(&ibs, 295, 180)) return;
	while(GetMessage(&msg, NULL, 0, 0))
	{
		TranslateMessage(&msg); 
		DispatchMessage(&msg);
	}

	StrFree(lpstrTitle);
	StrFree(lpstrNfo);
	StrFree(lpstrUser);
	StrFree(lpstrEdit1);
	StrFree(lpstrMax);
	StrFree(lpstrKey);
	StrFree(lpstrSerial);
	StrFree(lpstrOk);
	StrFree(lpstrCancel);
	StrFree(lpstrRet);

	UnRegisterClassEx(&ibs);
	return;
}

BOOL WINAPI DllMain(HANDLE hInst, ULONG ul_reason_for_call, LPVOID lpReserved)
{
	return TRUE;
}
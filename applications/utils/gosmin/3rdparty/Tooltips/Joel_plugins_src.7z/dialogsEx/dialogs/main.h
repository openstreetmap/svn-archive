// main.h
// This header file has the constants and function used in main.c

#ifndef DIALOGS_MAIN_H
#define DIALOGS_MAIN_H

// Include NSIS' header info
#include "exdll.h"

// Global Function entry
#define PLUGFUNCTION(name) void __declspec(dllexport) name(HWND hWndParent, int string_size, char *variables, stack_t **stacktop, extra_parameters *extra)

#define hWndDesktop GetDesktopWindow()

#define TONSIS(num,lpstr) setuservariable(num, lpstr)

typedef struct
{
    HWND hWndParent;
    LPSTR strDir;
    LPSTR strTitle;
    LPSTR strFilter;
    int iIndex;
    int iStyle;
    BOOL bType;
}OPENSAVEBOXSTRUCT, *LPOPENSAVEBOXSTRUCT;

typedef struct
{
    HWND hWndParent;
    LPSTR strTitle;
    LPSTR strInfo;
    LPSTR strDir;
    char strFolder[260];
    BOOL bIsModern;
} FOLDERBOXSTRUCT, *LPFOLDERBOXSTRUCT;

typedef struct
{
	HINSTANCE hInstance;
	HWND hWndParent;
	HWND hEdit1;
	HWND hEdit2;
	HWND hStatic1;
	HWND hStatic2;
	HWND hStatic3;
	HWND hIcon;
	HWND hButton1;
	HWND hButton2;
	LPSTR lpstrClassName;
	LPSTR lpstrTitle;
	LPSTR lpstrNfo;
	LPSTR lpstrUser;
	LPSTR lpstrReg;
	LPSTR lpstrKey;
	LPSTR lpstrEdit1;
	LPSTR lpstrEdit2;
	LPSTR lpstrOk;
	LPSTR lpstrCancel;
	BOOL bIsPwd;
	HICON hiCon;
	int iMax;
	int iRet;
} INPUTBOXSTRUCT, *LPINPUTBOXSTRUCT;

// ++++ Damn global vars >.<
WNDPROC Edit1Proc = NULL;
WNDPROC Edit2Proc = NULL;
HWND hEdit1 = NULL;
HWND hEdit2 = NULL;
HWND hButton1 = NULL;
HWND hButton2 = NULL;
char key[260]; // Inputed keycode from NSIS
int iRet = 0;

int _stdcall KeyGen(char* buffer, char* str, char* keycode)
{
	int a = 0;
	int b = 0;
	int c = 0;
	int d = 0;
	int e = 0;
	int f = 0;

	a = l_strlen(str);
	b = l_strlen(keycode);

	c = str[a/2];
	d = keycode[b/2];
	e = str[a-1];
	f = keycode[b-1];
	return wsprintf(buffer, "%X%x-%x%x-%x-%x-%x", ((a-f)-(e+c))^2, f^3, e+(a^3), (d+a)-(f^2), f, (a+b+c+d)/(e+f), (a^3));
}

BOOL WINAPI ValKey(HWND hwndEdit1, HWND hwndEdit2, char* KeyCode)
{
	BOOL bRet;
	char buff[260];
	LPSTR username;
	LPSTR usercode;
	int len1, len2;

	len1 = GetWindowTextLength(hwndEdit1);
	len2 = GetWindowTextLength(hwndEdit2);

	username = StrAlloc(len1);
	usercode = StrAlloc(len2);

	GetWindowText(hwndEdit1, username, len1+1);
	GetWindowText(hwndEdit2, usercode, len2+1);

	KeyGen(buff, username, KeyCode);
	if (l_strcmp(buff, usercode)==0)
	{
		bRet = TRUE;
	}
	else
	{
		bRet = FALSE;
	}
	TONSIS(0, buff);
	TONSIS(1, username);
	TONSIS(2, usercode);
	TONSIS(3, KeyCode);

	StrFree(username);
	StrFree(usercode);
	return bRet;
}

UINT APIENTRY OFNHookProcOldStyle(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
    switch (uMsg)
    {
        case WM_INITDIALOG:
            {
                return TRUE;
            }
        default:
            {
                break;
            }
    }
    return FALSE;
}

UINT APIENTRY OFNHookProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
    switch (uMsg)
    {
        case WM_INITDIALOG:
            {
                return TRUE;
            }
        default:
            {
                break;
            }
    }
    return FALSE;
}

BOOL OpenSaveBox(LPSTR lpbuffer, LPOPENSAVEBOXSTRUCT lpobs)
{
    OPENFILENAME ofn;
    DWORD dwFlags = OFN_FILEMUSTEXIST|OFN_PATHMUSTEXIST;
    
    ZeroMemory(&ofn, sizeof(OPENFILENAME)); 
    
    *lpbuffer = 0;
    
    ofn.lStructSize = sizeof(OPENFILENAME);
    ofn.hwndOwner = lpobs->hWndParent;
    ofn.nFilterIndex = lpobs->iIndex;
    ofn.lpstrFile = lpbuffer;
    ofn.nMaxFile = MAX_PATH;
    
    if (IsEmptyStr(lpobs->strTitle))
    {
        ofn.lpstrTitle = lpobs->strTitle;
    }
    
    if (IsEmptyStr(lpobs->strFilter))
    {
        ofn.lpstrFilter = lpobs->strFilter;
    }
    else
    {
        ofn.lpstrFilter = "(*.*)\0*.*\0\0";
    }
    
    if (IsEmptyStr(lpobs->strDir))
    {
        ofn.lpstrInitialDir = lpobs->strDir;
    }
    
    if (lpobs->bType)
    {
        dwFlags += OFN_CREATEPROMPT;
    }
    else
    {
        dwFlags += OFN_OVERWRITEPROMPT;
    }
    
    switch (lpobs->iStyle)
    {
        case 1: // Win 3.1
        {
            ofn.Flags = dwFlags|OFN_ENABLEHOOK|OFN_LONGNAMES;
            ofn.lpfnHook = OFNHookProcOldStyle;
            break;
        }
        case 2: // Win 95/98/NT
        {
            ofn.Flags = dwFlags|OFN_ENABLEHOOK|OFN_EXPLORER;
            ofn.lpfnHook = OFNHookProc;
            break;
        }
        default: // WinMe/2k/XP/3k
        {
            ofn.Flags = dwFlags|OFN_EXPLORER;
            break;
        }
    }
    
    if (lpobs->bType) return GetOpenFileName(&ofn);             
    return GetSaveFileName(&ofn);
}

int CALLBACK BrowseCallbackProc(HWND hwnd, UINT msg, LPARAM lParam, LPARAM lpData)
{
    LPFOLDERBOXSTRUCT lpfbs = (LPFOLDERBOXSTRUCT)lpData;
	switch (msg)
	{
	case BFFM_INITIALIZED:
		{
            if (IsEmptyStr(lpfbs->strTitle))
            {
                SetWindowText(hwnd, lpfbs->strTitle);
            }
            
            if (lpfbs->bIsModern)
            {      
		        HWND hTree = FindWindowEx(hwnd, NULL, "SysTreeView32", NULL);
		        SetWindowText(hTree, lpfbs->strTitle);
            }
            SendMessage(hwnd, BFFM_SETSELECTION, TRUE, (LPARAM)lpfbs->strDir);
			break;
		}
	case BFFM_SELCHANGED:
        {
			HWND hWnd;
            if (SHGetPathFromIDList((LPITEMIDLIST)lParam, lpfbs->strFolder))
            {
                if (!lpfbs->bIsModern)
                {
				    SendMessage(hwnd, BFFM_SETSTATUSTEXT, 0, (LPARAM)lpfbs->strFolder);
                }			
                else
			    {
                    hWnd = FindWindowEx(hwnd, NULL, "Edit", NULL);
				    SetWindowText(hWnd, lpfbs->strFolder);
                }
            }
            break;
        }
	default:
        {
            break;
        }
	}
	return 0;
}

BOOL FolderBoxA(LPSTR lpstrBuffer, LPFOLDERBOXSTRUCT lpfbs)
{
	BROWSEINFO bi;
	LPITEMIDLIST pidl;
	
	BOOL bRet;
	ZeroMemory(&bi, sizeof(BROWSEINFO));
		
	if (lpfbs->bIsModern)
	{
	   CoInitialize(NULL);
	   bi.ulFlags = BIF_RETURNONLYFSDIRS|BIF_USENEWUI;
    }
    else
    {
        if (IsEmptyStr(lpfbs->strInfo))
	    {
	       bi.lpszTitle = lpfbs->strInfo;
        }
        bi.ulFlags = BIF_RETURNONLYFSDIRS|BIF_STATUSTEXT;
    }
    
	pidl = (LPITEMIDLIST)CoTaskMemAlloc(sizeof(LPITEMIDLIST));
	
	bi.hwndOwner = lpfbs->hWndParent;
	bi.pidlRoot = NULL;
	bi.pszDisplayName = NULL;
	bi.lpfn = BrowseCallbackProc;
	bi.lParam = (LPARAM)lpfbs;

	pidl = SHBrowseForFolder(&bi);
	
	bRet = SHGetPathFromIDList(pidl, lpstrBuffer);
   
    if (lpfbs->bIsModern)
    {
        CoUninitialize();
    }
	CoTaskMemFree(pidl);
	return bRet;
}

BOOL WINAPI BeginInst(LPINPUTBOXSTRUCT lpibs, WNDPROC WinProc)
{
	WNDCLASSEX wcx;
	ZeroMemory(&wcx, sizeof(WNDCLASSEX));

	wcx.cbClsExtra = 0;
	wcx.cbSize = sizeof(WNDCLASSEX);
	wcx.cbWndExtra = 0;
	wcx.hbrBackground = GetSysColorBrush(COLOR_3DFACE);
	wcx.hCursor = LoadCursor(NULL, IDC_ARROW);
	wcx.hIcon = lpibs->hiCon;
	wcx.hIconSm = lpibs->hiCon;
	wcx.hInstance = lpibs->hInstance;
	wcx.lpfnWndProc = WinProc;
	wcx.lpszClassName = lpibs->lpstrClassName;
	wcx.lpszMenuName = 0;
	wcx.style = CS_DBLCLKS|CS_HREDRAW|CS_VREDRAW;
	return RegisterClassEx(&wcx);
}

BOOL WINAPI ShowMe(LPINPUTBOXSTRUCT lpibs, int w, int h)
{
	HWND hWnd;
	hWnd = CreateWindowEx(0, lpibs->lpstrClassName, lpibs->lpstrTitle, 
		   WS_POPUPWINDOW|WS_CAPTION|WS_SYSMENU|WS_VISIBLE|WS_OVERLAPPED, 
		   (GetSystemMetrics(SM_CXSCREEN)-w)/2, (GetSystemMetrics(SM_CYSCREEN)-h)/2, w, 
		   h, lpibs->hWndParent, 0, lpibs->hInstance, (LPVOID)lpibs);
	if (!hWnd) return FALSE;
	ShowWindow(hWnd, SW_SHOWNORMAL);
	UpdateWindow(hWnd);
	return TRUE;
}

BOOL WINAPI UnRegisterClassEx(LPINPUTBOXSTRUCT lpibs)
{
	BOOL bRet;
	bRet = UnregisterClass(lpibs->lpstrClassName, lpibs->hInstance);
	ZeroMemory(lpibs, sizeof(LPINPUTBOXSTRUCT));
	return bRet;
}

HRESULT WINAPI SetDefaultFont(HWND hwnd)
{
	return SendMessage(hwnd, WM_SETFONT, (WPARAM)GetStockObject(DEFAULT_GUI_FONT), 0);
}

VOID WINAPI ToggleButton(int iLen, HWND hButton)
{
	if (iLen <= 0) 
	{
		EnableWindow(hButton, FALSE);
	}
	else
	{
		EnableWindow(hButton, TRUE);
	}
	return;
}

VOID WINAPI SendTextToNsis(BOOL bValid, HWND hwnd, int iVar)
{
	LPSTR lpstrBuff;
	if (bValid)
	{
		int iLen = GetWindowTextLength(hwnd);
		lpstrBuff = (LPSTR)StrAlloc(iLen);
		GetWindowText(hwnd, lpstrBuff, iLen+1);
	}
	else
	{
		lpstrBuff = "";
	}
	TONSIS(iVar, lpstrBuff);
	if (bValid) 
	{
		StrFree(lpstrBuff);
	}
	return;
}

LRESULT CALLBACK SubEdit1Proc(HWND hWndParent, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	switch (uMsg)
	{
	case WM_KEYDOWN:
		{
			if ( (wParam == VK_TAB) && (IsWindow(hEdit2)) ) SetFocus(hEdit2);
			SendMessage(GetParent(hWndParent), uMsg, wParam, lParam);
			break;
		}
	}
	return CallWindowProc(Edit1Proc, hWndParent, uMsg, wParam, lParam);
}

LRESULT CALLBACK SubEdit2Proc(HWND hWndParent, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	switch (uMsg)
	{
	case WM_KEYDOWN:
		{
			SendMessage(GetParent(hWndParent), uMsg, wParam, lParam);
			break;
		}
	}
	return CallWindowProc(Edit2Proc, hWndParent, uMsg, wParam, lParam);
}

LRESULT CALLBACK IBProc(HWND hWndParent, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	switch (uMsg)
	{
	case WM_CREATE:
		{
			LPINPUTBOXSTRUCT lpibs = (LPINPUTBOXSTRUCT)(((LPCREATESTRUCT) lParam)->lpCreateParams);
			int len = 0;
			lpibs->hStatic1 = CreateWindowEx(0, "Static", lpibs->lpstrNfo, WS_CHILD|WS_VISIBLE, 3, 5, 220, 53, hWndParent, (HMENU)1201, lpibs->hInstance, 0);
			hEdit1 = lpibs->hEdit1 = CreateWindowEx(WS_EX_CLIENTEDGE, "Edit", lpibs->lpstrEdit1, WS_CHILD|WS_VISIBLE|ES_PASSWORD, 3, 60, 220, 20, hWndParent, (HMENU)1202, lpibs->hInstance, 0);
			if (!lpibs->bIsPwd) SendMessage(lpibs->hEdit1, EM_SETPASSWORDCHAR, 0, 0);
			SendMessage(lpibs->hEdit1, EM_SETLIMITTEXT, lpibs->iMax, 0);
			Edit1Proc = (WNDPROC)SetWindowLong(lpibs->hEdit1, GWL_WNDPROC, (LONG)SubEdit1Proc);

			if (!IsEmptyStr(lpibs->lpstrOk)) lpibs->lpstrOk = "OK";
			hButton1 = lpibs->hButton1 = CreateWindowEx(0, "Button", lpibs->lpstrOk, WS_CHILD|WS_VISIBLE, 230, 5, 55, 23, hWndParent, (HMENU)1203, lpibs->hInstance, 0);
			if (!IsEmptyStr(lpibs->lpstrCancel)) lpibs->lpstrCancel = "Cancel";
			hButton2 = lpibs->hButton2 = CreateWindowEx(0, "Button", lpibs->lpstrCancel, WS_CHILD|WS_VISIBLE, 230, 35, 55, 23, hWndParent, (HMENU)1204, lpibs->hInstance, 0);

			len = GetWindowTextLength(lpibs->hEdit1);
			ToggleButton(len, lpibs->hButton1);

			SetDefaultFont(lpibs->hStatic1);
			SetDefaultFont(lpibs->hEdit1);
			SetDefaultFont(lpibs->hButton1);
			SetDefaultFont(lpibs->hButton2);

			iRet = lpibs->iRet;
			SetFocus(lpibs->hEdit1);
			if (!lpibs->bIsPwd)
			{
				SendMessage(lpibs->hEdit1, EM_SETSEL, 0, len);
				SendMessage(lpibs->hEdit1, EM_SCROLLCARET, 0, 0);
			}
			return TRUE;
		}
	case WM_COMMAND:
		{
			switch (LOWORD(wParam))
			{
			case 1202:
				{
					switch (HIWORD(wParam))
					{
					case EN_CHANGE:
						{
							int len = GetWindowTextLength((HWND)lParam);
							ToggleButton(len, hButton1);
							break;
						}
					}
					break;
				}
			case 1203:
				{
					SendTextToNsis(TRUE, hEdit1, iRet);
					SendMessage(hWndParent, WM_CLOSE, 0, 0);
					break;
				}
			case 1204:
				{
					SendTextToNsis(FALSE, hEdit1, iRet);
					SendMessage(hWndParent, WM_CLOSE, 0, 0);
					break;
				}
			}
			return TRUE;
		}
	case WM_RBUTTONDOWN:
	case WM_LBUTTONDOWN:
		{
			SetFocus(hWndParent);
			return FALSE;
		}
	case WM_KEYDOWN:
		{
			switch(wParam)
			{
			case VK_ESCAPE:
				{
					SendTextToNsis(FALSE, hEdit1, iRet);
					SendMessage(hWndParent, WM_CLOSE, 0, 0);
					break;
				}
			case VK_RETURN:
				{
					if (IsWindowEnabled(hButton1))
					{
						SendTextToNsis(TRUE, hEdit1, iRet);
						SendMessage(hWndParent, WM_CLOSE, 0, 0);
					}
					break;
				}
			}
			return TRUE;
		}
	case WM_NOTIFY:
		{
			return FALSE;
		}
	case WM_CLOSE:
		{
			SetWindowLong(hEdit1, GWL_WNDPROC, (LONG)Edit1Proc);
			iRet = 0;
			DestroyWindow(hEdit1);
			DestroyWindow(hButton1);
			DestroyWindow(hButton2);
			DestroyWindow(hWndParent);
			return TRUE;
		}
	case WM_DESTROY:
		{
			PostQuitMessage(0);
			return TRUE;
		}
	default:
		{
			return DefWindowProc(hWndParent, uMsg, wParam, lParam);
		}
	}
	return FALSE;
}

LRESULT CALLBACK IRProc(HWND hWndParent, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	switch (uMsg)
	{
	case WM_CREATE:
		{
			LPINPUTBOXSTRUCT lpibs = (LPINPUTBOXSTRUCT)(((LPCREATESTRUCT) lParam)->lpCreateParams);
			int len = 0;
			lpibs->hStatic1 = CreateWindowEx(0, "Static", lpibs->lpstrNfo, WS_CHILD|WS_VISIBLE, 1, 5, 220, 40, hWndParent, (HMENU)1201, lpibs->hInstance, 0);

			lpibs->hStatic2 = CreateWindowEx(0, "Static", lpibs->lpstrUser, WS_CHILD|WS_VISIBLE, 1, 55, 220, 15, hWndParent, (HMENU)1202, lpibs->hInstance, 0);
			hEdit1 = lpibs->hEdit1 = CreateWindowEx(WS_EX_CLIENTEDGE, "Edit", lpibs->lpstrEdit1, WS_CHILD|WS_VISIBLE, 1, 70, 220, 20, hWndParent, (HMENU)1203, lpibs->hInstance, 0);
			SendMessage(lpibs->hEdit1, EM_SETLIMITTEXT, lpibs->iMax, 0);

			lpibs->hStatic3 = CreateWindowEx(0, "Static", lpibs->lpstrReg, WS_CHILD|WS_VISIBLE, 1, 100, 220, 15, hWndParent, (HMENU)1204, lpibs->hInstance, 0);
			hEdit2 = lpibs->hEdit2 = CreateWindowEx(WS_EX_CLIENTEDGE, "Edit", lpibs->lpstrEdit2, WS_CHILD|WS_VISIBLE|ES_PASSWORD, 1, 115, 220, 20, hWndParent, (HMENU)1205, lpibs->hInstance, 0);

			if (!IsEmptyStr(lpibs->lpstrOk)) lpibs->lpstrOk = "OK";
			hButton1 = lpibs->hButton1 = CreateWindowEx(0, "Button", lpibs->lpstrOk, WS_CHILD|WS_VISIBLE, 230, 5, 55, 23, hWndParent, (HMENU)1206, lpibs->hInstance, 0);
			if (!IsEmptyStr(lpibs->lpstrCancel)) lpibs->lpstrCancel = "Cancel";
			lpibs->hButton2 = CreateWindowEx(0, "Button", lpibs->lpstrCancel, WS_CHILD|WS_VISIBLE, 230, 35, 55, 23, hWndParent, (HMENU)1207, lpibs->hInstance, 0);

			lpibs->hIcon = CreateWindowEx(0, "Static", NULL, WS_CHILD|WS_VISIBLE|SS_ICON, 240, 90, 32, 32, hWndParent, (HMENU)1208, lpibs->hInstance, 0);
			SendMessage(lpibs->hIcon, STM_SETIMAGE, IMAGE_ICON, (WPARAM)lpibs->hiCon);

			SetDefaultFont(lpibs->hStatic1);
			SetDefaultFont(lpibs->hStatic2);
			SetDefaultFont(lpibs->hStatic3);
			SetDefaultFont(lpibs->hEdit1);
			SetDefaultFont(lpibs->hEdit2);
			SetDefaultFont(lpibs->hButton1);
			SetDefaultFont(lpibs->hButton2);

			Edit1Proc = (WNDPROC)SetWindowLong(hEdit1, GWL_WNDPROC, (LONG)SubEdit1Proc);
			Edit2Proc = (WNDPROC)SetWindowLong(hEdit2, GWL_WNDPROC, (LONG)SubEdit2Proc);

			len = GetWindowTextLength(hEdit1);

			ToggleButton(len, hButton1);
			l_strcpy(key, lpibs->lpstrKey);
			iRet = lpibs->iRet;

			SetFocus(lpibs->hEdit1);
			
			SendMessage(lpibs->hEdit1, EM_SETSEL, 0, len);
			SendMessage(lpibs->hEdit1, EM_SCROLLCARET, 0, 0);
			return TRUE;
		}
	case WM_COMMAND:
		{
			switch (LOWORD(wParam))
			{
			case 1202:
				{
					break;
				}
			case 1203:
				{
					switch (HIWORD(wParam))
					{
					case EN_CHANGE:
						{
							int len = GetWindowTextLength((HWND)lParam);
							ToggleButton(len, hButton1);
							break;
						}
					}
					break;
				}
			case 1206: // OK
				{
					if (ValKey(hEdit1, hEdit2, key))
					{
						TONSIS(iRet, "1");
					}
					else
					{
						TONSIS(iRet, "0");
					}
					SendMessage(hWndParent, WM_CLOSE, 0, 0);
					break;
				}
			case 1207: // Cancel
				{
					TONSIS(iRet, "0");
					SendMessage(hWndParent, WM_CLOSE, 0, 0);
					break;
				}
			}
			return TRUE;
		}
	case WM_LBUTTONDOWN:
		{
			SetFocus(hWndParent);
			return FALSE;
		}
	case WM_KEYDOWN:
		{
			switch(wParam)
			{
			case VK_ESCAPE:
				{
					TONSIS(iRet, "0");
					SendMessage(hWndParent, WM_CLOSE, 0, 0);
					break;
				}
			case VK_RETURN:
				{
					if (ValKey(hEdit1, hEdit2, key))
					{
						TONSIS(iRet, "1");
					}
					else
					{
						TONSIS(iRet, "0");
					}
					SendMessage(hWndParent, WM_CLOSE, 0, 0);
					break;
				}
			}
			return TRUE;
		}
	case WM_NOTIFY:
		{
			return FALSE;
		}
	case WM_CLOSE:
		{
			SetWindowLong(hEdit1, GWL_WNDPROC, (LONG)Edit1Proc);
			SetWindowLong(hEdit2, GWL_WNDPROC, (LONG)Edit2Proc);
			DestroyWindow(hWndParent);
			return TRUE;
		}
	case WM_DESTROY:
		{
			PostQuitMessage(0);
			return TRUE;
		}
	default:
		{
			return DefWindowProc(hWndParent, uMsg, wParam, lParam);
		}
	}
	return FALSE;
}

#endif
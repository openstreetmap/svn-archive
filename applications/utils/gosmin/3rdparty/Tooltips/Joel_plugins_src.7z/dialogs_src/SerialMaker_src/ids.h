// Archivo de IDs:

#define IDC_STATIC1		1101
#define IDC_STATIC2		1102
#define IDC_STATIC3		1103

#define IDC_EDIT1		1201
#define IDC_EDIT2		1202
#define IDC_EDIT3		1203

#define IDC_BUTTON1		1301
#define IDC_BUTTON2		1302
#define IDC_BUTTON3		1303

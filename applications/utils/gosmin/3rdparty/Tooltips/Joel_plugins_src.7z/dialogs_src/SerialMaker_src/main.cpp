#pragma comment(lib, "libctiny.lib")
#pragma comment(lib, "comctl32.lib")

#include <windows.h>
#include <commctrl.h>
#include "resource.h"
#include "modulo.h"

HINSTANCE hInst;
HWND hStatic1, hStatic2, hStatic3;
HWND hEdit1, hEdit2, hEdit3;
HWND hButton1, hButton2, hButton3; 

LRESULT CALLBACK WinProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	switch (msg)
	{
	case WM_CREATE:
		{
			InitCommonControls();
			hStatic1 = CreateStatic(hwnd, IDC_STATIC1, "Username", WS_CHILD|WS_VISIBLE, 5, 5, 50, 15);
			SetDefaultFont(hStatic1);

			hEdit1 = CreateEdit(hwnd, IDC_EDIT1, NULL, WS_CHILD|WS_VISIBLE, 5, 20, 250, 20);
			SetDefaultFont(hEdit1);

			hStatic2 = CreateStatic(hwnd, IDC_STATIC2, "Keyname", WS_CHILD|WS_VISIBLE, 5, 50, 50, 15);
			SetDefaultFont(hStatic2);

			hEdit2 = CreateEdit(hwnd, IDC_EDIT2, NULL, WS_CHILD|WS_VISIBLE, 5, 65, 250, 20);
			SetDefaultFont(hEdit2);

			hStatic3 = CreateStatic(hwnd, IDC_STATIC3, "Serial", WS_CHILD|WS_VISIBLE, 5, 95, 50, 15);
			SetDefaultFont(hStatic3);

			hEdit3 = CreateEdit(hwnd, IDC_EDIT3, NULL, WS_CHILD|WS_VISIBLE|ES_READONLY, 5, 110, 250, 20);
			SetDefaultFont(hEdit3);

			hButton1 = CreateButton(hwnd, IDC_BUTTON1, "Generate", WS_CHILD|WS_VISIBLE, 5, 140, 55, 20);
			SetDefaultFont(hButton1);

			hButton2 = CreateButton(hwnd, IDC_BUTTON2, "Reset", WS_CHILD|WS_VISIBLE, 70, 140, 55, 20);
			SetDefaultFont(hButton2);

			hButton3 = CreateButton(hwnd, IDC_BUTTON3, "About", WS_CHILD|WS_VISIBLE, 135, 140, 55, 20);
			SetDefaultFont(hButton3);
			return TRUE;
		}
	case WM_COMMAND:
		{
			switch (LOWORD(wParam))
			{
			case IDC_BUTTON1:
				{
					char Username[MAX_PATH];
					char Keyname[MAX_PATH];
					char buff[MAX_PATH];

					int lenUser = GetWindowText(hEdit1, Username, sizeof(Username));
					int lenKey = GetWindowText(hEdit2, Keyname, sizeof(Keyname));

					if (lenUser == 0)
					{
						MessageBox(hwnd, "Please input Username", "Oops...", 48);
						SetFocus(hEdit1);
					}
					else if (lenKey == 0)
					{
						MessageBox(hwnd, "Please input Keyname", "Oops...", 48);
						SetFocus(hEdit2);
					}
					else
					{
						KeyGen(buff, Username, Keyname, lenUser, lenKey);
						SetWindowText(hEdit3, buff);
					}

					break;
				}
			case IDC_BUTTON2:
				{
					SetWindowText(hEdit1, NULL);
					SetWindowText(hEdit2, NULL);
					SetWindowText(hEdit3, NULL);
					break;
				}
			case IDC_BUTTON3:
				{
					MessageBox(hwnd, "Author: Lobo Lunar.\nProject: dialogs.\nEmail: lobo@lobo-lunar.com", "About...", 64);
					break;
				}
			}
			return TRUE;
		}
	case WM_CLOSE:
		{
			DestroyWindow(hStatic1);
			DestroyWindow(hStatic2);
			DestroyWindow(hStatic3);
			DestroyWindow(hEdit1);
			DestroyWindow(hEdit2);
			DestroyWindow(hEdit3);
			DestroyWindow(hButton1);
			DestroyWindow(hButton2);
			DestroyWindow(hButton3);
			DestroyWindow(hwnd);
			return TRUE;
		}
	case WM_DESTROY:
		{
			PostQuitMessage(0);
			return TRUE;
		}
	default:
		{
			return DefWindowProc (hwnd, msg, wParam, lParam);
		}
	}
	return FALSE;
}

int WINAPI WinMain(HINSTANCE ghInst, HINSTANCE prevInst, LPSTR lpCmdLine, int nShowCmd)
{
	WNDCLASSEX wcx;
	MSG msg;
	HWND hwnd;
	int x;
	int y;

	hInst = ghInst;

	wcx.cbSize = sizeof(WNDCLASSEX);
	wcx.hInstance = ghInst;
	wcx.lpszClassName = "SM_CLASE";
	wcx.lpfnWndProc = WinProc;
	wcx.style = CS_DBLCLKS;
	wcx.hIcon = LoadIcon (ghInst, MAKEINTRESOURCE(IDI_ICON1));
	wcx.hIconSm = LoadIcon (ghInst, MAKEINTRESOURCE(IDI_ICON1));
	wcx.hCursor = LoadCursor (NULL, IDC_ARROW);
	wcx.lpszMenuName = 0;                
    wcx.cbClsExtra = 0;                  
    wcx.cbWndExtra = 0;
	wcx.hbrBackground = GetSysColorBrush(COLOR_3DFACE);

	if (!RegisterClassEx (&wcx))
	{
		MessageBox(0, "La clase no fue registrada", "Class error", 16);
		return 0;
	}

	x = 300;
	y = 200;

	hwnd = CreateWindowEx(0,wcx.lpszClassName,TEXT("Dialogs - SerialMaker"),WS_POPUPWINDOW|WS_CAPTION|WS_SYSMENU|WS_MINIMIZEBOX|WS_VISIBLE|WS_OVERLAPPED,(GetSystemMetrics(SM_CXSCREEN)-x)/2,(GetSystemMetrics(SM_CYSCREEN)-y)/2,x,y,HWND_DESKTOP,0,ghInst,0);
	
	if (!hwnd)
	{
		MessageBox(0, "La ventana no fue creada", "hwnd error", 16);
		return 0;
	}

	ShowWindow(hwnd, SW_SHOWNORMAL);
	UpdateWindow(hwnd);


	while (GetMessage (&msg, 0, 0, 0)>0) 
	{
		TranslateMessage(&msg);
		DispatchMessage(&msg);
	}

	UnregisterClass(wcx.lpszClassName, ghInst);

	return msg.wParam;
}

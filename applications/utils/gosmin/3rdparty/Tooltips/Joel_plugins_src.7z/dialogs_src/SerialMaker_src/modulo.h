#include "ids.h"

int SetDefaultFont(HWND hwnd)
{
	return SendMessage(hwnd, WM_SETFONT, (WPARAM)GetStockObject(DEFAULT_GUI_FONT), 0);
}

HWND CreateStatic(HWND hwnd, int id, char* sztexto, DWORD dwestilos, int x, int y, int w, int h)
{
	return CreateWindowEx(0, TEXT("STATIC"), TEXT(sztexto), dwestilos, x, y, w, h, hwnd, (HMENU)id, GetModuleHandle(NULL), NULL);
}

HWND CreateEdit(HWND hwnd, int id, char* sztexto, DWORD dwestilos, int x, int y, int w, int h)
{
	return CreateWindowEx(WS_EX_CLIENTEDGE, TEXT("EDIT"), TEXT(sztexto), dwestilos, x, y, w, h, hwnd, (HMENU)id, GetModuleHandle(NULL), NULL);
}

HWND CreateButton(HWND hwnd, int id, char* sztexto, DWORD dwestilos, int x, int y, int w, int h)
{
	return CreateWindowEx(0, TEXT("BUTTON"), TEXT(sztexto), dwestilos, x, y, w, h, hwnd, (HMENU)id, GetModuleHandle(NULL), NULL);
}

int KeyGen(char buffer[255], char s[255], char key[255], int lens, int lenkey)
{
	int ret = 0;
	int x = lens+65;
	int y = lens+lenkey+65;
	int a = 122-lens;
	int b = 122-lenkey;
	int c = 65+(lens*2);
	int d = 122-(lenkey+lens);
	int e = 97+lens;
	int f = 97+lenkey;
	int bloque1 = (lens)*(lenkey)*(lenkey);
	int bloque2 = (*s)*(*key)+(*s)+(lens)*(lenkey);
	if(int len = wsprintf(buffer,"%c%c%c%c-%i-%i-%c%c%c%c", x, y, a, b, bloque1, bloque2, c, d, e, f))
	{
		ret = len;
	}
	return ret;
}

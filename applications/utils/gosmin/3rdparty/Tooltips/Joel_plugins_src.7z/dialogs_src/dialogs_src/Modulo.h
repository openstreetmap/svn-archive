#ifndef BIF_USENEWUI
#define BIF_USENEWUI 0x40
#endif

#define ID_INPUT_STATIC1	1001
#define ID_INPUT_EDIT1		1002
#define ID_INPUT_BUTTON1	1003
#define ID_INPUT_BUTTON2	1004

#define ID_REG_STATIC1		1005
#define ID_REG_STATIC2		1006
#define ID_REG_STATIC3		1007
#define ID_REG_EDIT1		1008
#define ID_REG_EDIT2		1009
#define ID_REG_BUTTON1		1010
#define ID_REG_BUTTON2		1011

int mi_strlen(char* InputString)
{
	int i = 0;
	while(*InputString)
	{
		i++;
		InputString++;
	}
	return i;
}

void mi_strncpy(char* Buffer, char* StringToCopy, int NumberOfCharsToCopy)
{
	int index = 0;
	for(int i = 0; i < NumberOfCharsToCopy; i++)
	{
		Buffer[index] = StringToCopy[i];
		index++;
	}
	Buffer[index] = 0;
}

void mi_strcpy(char* Buffer, char* StringToCopy)
{
	int index = 0;
	for(int i = 0; i < mi_strlen(StringToCopy); i++)
	{
		Buffer[index] = StringToCopy[i];
		index++;
	}
	Buffer[index] = 0;
}

int mi_atoi(char *StringToInteger)
{
	unsigned int v=0;
	for (;;)
	{
		int c=*StringToInteger++ - '0';
		if (c < 0 || c > 9) break;
		v*=10;
		v+=c;
	}
  return (int)v;
}

int mi_strcmp(char* String1, char* String2)
{
	while(*String1 == * String2 && *String1)
	{
		String1++;
		String2++;
	}
	return *String1 - *String2;
}

char* replacechar(char* buff,char findchr, char replace)
{
	int len;
	len = mi_strlen(buff);
	for(int z = 0; z < len; z++)
	{
		if(buff[z] == findchr)
		{
			buff[z] = replace;
		}
	}
	return buff;
}

BOOL AbrirDLG(char buffer[MAX_PATH], HWND hwnd, char patern[MAX_PATH], int nIndex, char titulo[MAX_PATH], char inicio[MAX_PATH])
{
	OPENFILENAME ofn;
	ZeroMemory(&ofn, sizeof(OPENFILENAME));
	ofn.Flags = OFN_EXPLORER|OFN_FILEMUSTEXIST|OFN_HIDEREADONLY;
	ofn.hwndOwner = hwnd;
	ofn.lpstrInitialDir = inicio;
	ofn.lpstrFile = buffer;
	ofn.nFilterIndex = nIndex;
	ofn.lpstrFilter = replacechar(patern,'|','\0');
	ofn.lpstrTitle = titulo;
	ofn.lStructSize = sizeof(OPENFILENAME);
	ofn.nMaxFile = MAX_PATH;
	if (GetOpenFileName(&ofn))
	{
		return TRUE;
	}
	else
	{
		return FALSE;
	}
}

BOOL GuardarDLG(char buffer[MAX_PATH], HWND hwnd, char patern[MAX_PATH], int nIndex, char titulo[MAX_PATH], char inicio[MAX_PATH])
{
	OPENFILENAME sfn;
	ZeroMemory(&sfn, sizeof(OPENFILENAME));
	sfn.hwndOwner = hwnd;
	sfn.Flags = OFN_EXPLORER|OFN_FILEMUSTEXIST|OFN_OVERWRITEPROMPT;
	sfn.lpstrFile = buffer;
	sfn.nFilterIndex = nIndex;
	sfn.lpstrFilter = replacechar(patern,'|','\0');
	sfn.lpstrInitialDir = inicio;
	sfn.lStructSize = sizeof(OPENFILENAME);
	sfn.nMaxFile = MAX_PATH;
	sfn.lpstrTitle = titulo;
	if (GetSaveFileName(&sfn))
	{
		return TRUE;
	}
	else
	{
		return FALSE;
	}
}

char lptitulo[MAX_PATH];
char lpdir[MAX_PATH];

int CALLBACK FolderProc(HWND hwnd, UINT msg, LPARAM lParam, LPARAM lpData)
{
	switch (msg)
	{
	case BFFM_INITIALIZED:
		{
			SetWindowText(hwnd, lptitulo);
			SendMessage(hwnd, BFFM_SETSELECTION, TRUE, (LPARAM)lpdir);
			break;
		}
	}
	return 0;
}

BOOL FolderDLG(char buffer[MAX_PATH], HWND hwnd, char titulo[MAX_PATH], char info[MAX_PATH], char dir[MAX_PATH])
{
	mi_strcpy(lptitulo, titulo);
	mi_strcpy(lpdir, dir);
	BROWSEINFO bi;
	LPITEMIDLIST pidl;
	IMalloc *pMalloc;
    SHGetMalloc(&pMalloc);
	ZeroMemory(&bi, sizeof(BROWSEINFO));
	bi.hwndOwner = hwnd;
	bi.pidlRoot = NULL;
	bi.pszDisplayName = buffer;
	bi.lpszTitle = info;
	bi.ulFlags = BIF_RETURNONLYFSDIRS|BIF_DONTGOBELOWDOMAIN;
	bi.lParam = 0;
	bi.lpfn = FolderProc;
	pidl = SHBrowseForFolder(&bi);
	if (SHGetPathFromIDList(pidl,buffer))
	{
		if (pMalloc)
		{
			pMalloc->Free(pidl);
			pMalloc->Release();
		}
		return TRUE;
	}
	else
	{
		return FALSE;
	}
}

HWND CrearControl(HWND hwnd, int nID, LPCSTR lpControl, LPCSTR lpCaption, int x, int y, int w, int h, DWORD dwEstiloEx, DWORD dwEstilos)
{
	HWND hCtrl = 0;
	hCtrl = CreateWindowEx(dwEstiloEx,lpControl,lpCaption,dwEstilos,x,y,w,h,hwnd,(HMENU)nID,GetModuleHandle(NULL),0);
	SendMessage(hCtrl, WM_SETFONT, (WPARAM)GetStockObject(DEFAULT_GUI_FONT), 0);
	return hCtrl;
}

int CrearDlg(HINSTANCE hInst, HWND hwnd, DLGPROC dlgproc)
{
	HGLOBAL hgbl;
	LPDLGTEMPLATE lpdt;
	LPWORD lpw;
	LPWSTR lpwsz;

	// +++ Creaci�n del di�logo +++
	hgbl = GlobalAlloc(GMEM_ZEROINIT, 1024);
	lpdt = (LPDLGTEMPLATE)GlobalLock(hgbl);
	lpdt->cdit = 0;
	lpdt->cx = 170; lpdt->cy = 60;
	lpdt->style = WS_POPUP|WS_BORDER|DS_CENTER|DS_MODALFRAME|WS_CAPTION;
	lpdt->x = 0; lpdt->y = 0;
	lpw = (LPWORD) (lpdt + 1);
	*lpw++ = 0; *lpw++ = 0; lpwsz = (LPWSTR) lpw;
	// +++ Fin del di�logo +++

	GlobalUnlock(hgbl); 
	int ret = DialogBoxIndirect(hInst, (LPDLGTEMPLATE)hgbl, hwnd, (DLGPROC)dlgproc);
	GlobalFree(hgbl); 
	return ret;
}

// Keygen:
int KeyGen(char buffer[255], char s[255], char key[255], int lens, int lenkey)
{
	int ret = 0;
	int x = lens+65;
	int y = lens+lenkey+65;
	int a = 122-lens;
	int b = 122-lenkey;
	int c = 65+(lens*2);
	int d = 122-(lenkey+lens);
	int e = 97+lens;
	int f = 97+lenkey;
	int bloque1 = (lens)*(lenkey)*(lenkey);
	int bloque2 = (*s)*(*key)+(*s)+(lens)*(lenkey);
	if(int len = wsprintf(buffer,"%c%c%c%c-%i-%i-%c%c%c%c", x, y, a, b, bloque1, bloque2, c, d, e, f))
	{
		ret = len;
	}
	return ret;
}



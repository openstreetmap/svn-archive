#include <windows.h>
#include <commctrl.h>
#include <shlobj.h>
#include "Modulo.h"
#include "exdll.h"
#include "dll.h"

#if !__GNUC__
	//#pragma comment(lib, "libctiny.lib")
	#pragma comment(linker, "/defaultlib:kernel32.lib")
	#pragma comment(linker, "/nodefaultlib:libc.lib")
	#pragma comment(linker, "/nodefaultlib:libcmt.lib")
	#pragma comment(linker, "/nodefaultlib:msvcrt.lib")
	#pragma comment (linker, "/entry:\"DllMainCRTStartup\"")
#endif
#if (_MSVC_VER < 1200)
#pragma comment(linker,"/OPT:NOWIN98")
#pragma comment(linker, "/merge:.rdata=.data")
#pragma comment(linker, "/merge:.text=.data")
#pragma comment(linker, "/merge:.reloc=.data")
#pragma comment(linker,"/IGNORE:4078")
#endif


#if defined(_WINDOWS_) && defined(_cplusplus)
void* operator new(unsigned int nSize)
{
	return HeapAlloc(GetProcessHeap(), 0, nSize);
}

void operator delete(void *pMem)
{
	if(pMem) HeapFree(GetProcessHeap(), 0, pMem);
}
#endif

// Instancia:
HINSTANCE mi_hInst;

// Los HWNDs:

// InputBox (ip) hwnd's:
HWND hipStatic1; 
HWND hipEdit1; 
HWND hipButton1;
HWND hipButton2;

// RegCode (rc) hwnd's:
HWND hrcStatic1;
HWND hrcStatic2;
HWND hrcStatic3; 
HWND hrcEdit1;
HWND hrcEdit2; 
HWND hrcButton1;
HWND hrcButton2;

// InputBox (ip) string's vars:
char iptitulo[MAX_PATH];
char iptexto[MAX_PATH];
char ipb1[MAX_PATH];
char ipb2[MAX_PATH];
char ipchar[MAX_PATH];
char ipret[MAX_PATH];

// RegCode (rc) string's vars:
char rctitulo[MAX_PATH];
char rctexto[MAX_PATH];
char rcuser[MAX_PATH];
char rcregkey[MAX_PATH];
char rckey[MAX_PATH];
char rcb1[MAX_PATH];
char rcb2[MAX_PATH];
char rcret[MAX_PATH];

#define Function(name) extern "C" void __declspec(dllexport) name(HWND hwnd, int string_size, char *variables, stack_t **stacktop)

Function(Author)
{
	EXDLL_INIT();
	{
		char ret[MAX_PATH];
		popstring(ret);
		RetVar(mi_atoi(ret), "Lobo Lunar");
	}
}

Function(Ver)
{
	EXDLL_INIT();
	{
		char ret[MAX_PATH];
		popstring(ret);
		RetVar(mi_atoi(ret), "2.3"); //La versi�n actual
	}
}

Function(Open) // listo!
{
	EXDLL_INIT();
	{
		char filtros[MAX_PATH]; char sIndex[MAX_PATH]; char titulo[MAX_PATH]; char inicio[MAX_PATH]; char ret[MAX_PATH];
		popstring(filtros); popstring(sIndex); popstring(titulo); popstring(inicio); popstring(ret);
		char lpbuffer[MAX_PATH] = "\0";
		if (!AbrirDLG(lpbuffer, hwnd, filtros, mi_atoi(sIndex), titulo, inicio))
		{
			RetVar(mi_atoi(ret), "0");
		}
		else
		{
			RetVar(mi_atoi(ret), lpbuffer);
		}
	}
}

Function(Save) // listo!
{
	EXDLL_INIT();
	{
		char filtros[MAX_PATH]; char sIndex[MAX_PATH]; char titulo[MAX_PATH]; char inicio[MAX_PATH]; char ret[MAX_PATH];
		popstring(filtros); popstring(sIndex); popstring(titulo); popstring(inicio); popstring(ret);
		char lpbuffer[MAX_PATH] = "\0";
		if (GuardarDLG(lpbuffer, hwnd, filtros, mi_atoi(sIndex), titulo, inicio))
		{
			RetVar(mi_atoi(ret), lpbuffer);
		}
		else
		{
			RetVar(mi_atoi(ret), "0");
		}
	}
}

Function(Folder) // Listo!
{
	EXDLL_INIT();
	{
		char titulo[MAX_PATH]; char info[MAX_PATH]; char dir[MAX_PATH]; char ret[MAX_PATH];
		popstring(titulo); popstring(info); popstring(dir); popstring(ret);
		char lpbuffer[MAX_PATH] = "\0";
		if (FolderDLG(lpbuffer, hwnd, titulo, info, dir))
		{
			RetVar(mi_atoi(ret), lpbuffer);
		}
		else
		{
			RetVar(mi_atoi(ret), "");
		}
	}
}

LRESULT CALLBACK IBProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam) //Listo!
{
	switch (msg)
	{
	case WM_COMMAND:
		{
			switch(LOWORD(wParam))
			{
			case ID_INPUT_BUTTON1:
				{
					char buffer[MAX_PATH];
					GetWindowText(hipEdit1, buffer, sizeof(buffer));
					RetVar(mi_atoi(ipret), buffer);
					EndDialog(hWnd, false); break;
				}
			case ID_INPUT_BUTTON2:
				{
					EndDialog(hWnd, false);	break;
				}
			}
			break;
		}
	case WM_CLOSE:
	case WM_DESTROY:
		{
			EndDialog(hWnd, false); break;
		}
	case WM_INITDIALOG:
		{
			hipStatic1 = CrearControl(hWnd, ID_INPUT_STATIC1, "STATIC", "", 5, 5, 320, 70, 0, WS_VISIBLE|WS_CHILD);
			hipEdit1 = CrearControl(hWnd, ID_INPUT_EDIT1, "EDIT", "", 5, 92, 327, 20, WS_EX_CLIENTEDGE, WS_VISIBLE|WS_CHILD|WS_TABSTOP);
			hipButton1 = CrearControl(hWnd, ID_INPUT_BUTTON1, "BUTTON", "", 265, 5, 70, 23, 0, WS_VISIBLE|WS_CHILD|WS_TABSTOP);
			hipButton2 = CrearControl(hWnd, ID_INPUT_BUTTON2, "BUTTON", "", 265, 37, 70, 23, 0, WS_VISIBLE|WS_CHILD|WS_TABSTOP);
			if (mi_strcmp(ipchar,"1")==0)
			{
				SendMessage(hipEdit1, EM_SETPASSWORDCHAR, '*', 0);
			}
			SetWindowText(hWnd, iptitulo);
			SetWindowText(hipStatic1, iptexto);
			SetWindowText(hipButton1, ipb1);
			SetWindowText(hipButton2, ipb2);
			break;
		}
	}
	return FALSE;
}

Function(InputBox) // Listo!
{
	EXDLL_INIT();
	{
		char titulo[MAX_PATH]; char texto[MAX_PATH]; char b1[MAX_PATH]; char b2[MAX_PATH]; char chr[MAX_PATH]; char ret[MAX_PATH];
		popstring(titulo); popstring(texto); popstring(b1); popstring(b2); popstring(chr); popstring(ret);
		mi_strcpy(iptitulo, titulo); mi_strcpy(iptexto, texto); mi_strcpy(ipb1, b1); mi_strcpy(ipb2, b2); mi_strcpy(ipchar, chr); mi_strcpy(ipret, ret);
		CrearDlg(mi_hInst, hwnd, (DLGPROC)IBProc);
	}
}

LRESULT CALLBACK RegCodeProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam) // Listo!
{
	switch (msg)
	{
	case WM_COMMAND:
		{
			switch(LOWORD(wParam))
			{
			case ID_REG_BUTTON1:
				{
					int ret = 0;
					char UserName[MAX_PATH]; // user inputed name
					char UserCode[MAX_PATH]; // user inputed serial 
					char BuffCode[MAX_PATH]; // Real code
					char buffer[MAX_PATH]; // KeyGen's ret
					int lens = GetWindowText(hrcEdit1, UserName, sizeof(UserName)+1);
					GetWindowText(hrcEdit2, UserCode, sizeof(UserCode)+1);
					int lenkey = mi_strlen(rckey);
					KeyGen(buffer, UserName, rckey, lens, lenkey);
					if( (mi_strcmp(UserCode, buffer)==0))
					{
						ret = 0; // Iguales
					}
					else
					{
						ret = 1; // No es
					}
					wsprintf(BuffCode, "%i", ret);
					RetVar(mi_atoi(rcret), BuffCode);
					EndDialog(hWnd, false); break;
				}
			case ID_REG_BUTTON2:
				{
					RetVar(mi_atoi(rcret), "1");
					EndDialog(hWnd, false);	break;
				}
			}
			break;
		}
	case WM_CLOSE:
	case WM_DESTROY:
		{
			EndDialog(hWnd, false); break;
		}
	case WM_INITDIALOG:
		{
			hrcStatic1 = CrearControl(hWnd, ID_REG_STATIC1, "STATIC", "", 5, 5, 320, 50, 0, WS_VISIBLE|WS_CHILD);
			hrcStatic2 = CrearControl(hWnd, ID_REG_STATIC2, "STATIC", "", 5, 40, 50, 15, 0, WS_VISIBLE|WS_CHILD);
			hrcEdit1 = CrearControl(hWnd, ID_REG_EDIT1, "EDIT", "", 5, 53, 327, 20, WS_EX_CLIENTEDGE, WS_VISIBLE|WS_CHILD|WS_TABSTOP);
			hrcStatic3 = CrearControl(hWnd, ID_REG_STATIC3, "STATIC", "", 5, 79, 50, 15, 0, WS_VISIBLE|WS_CHILD);
			hrcEdit2 = CrearControl(hWnd, ID_REG_EDIT1, "EDIT", "", 5, 92, 327, 20, WS_EX_CLIENTEDGE, WS_VISIBLE|WS_CHILD|WS_TABSTOP|ES_PASSWORD);
			hrcButton1 = CrearControl(hWnd, ID_REG_BUTTON1, "BUTTON", "", 265, 3, 70, 23, 0, WS_VISIBLE|WS_CHILD|WS_TABSTOP);
			hrcButton2 = CrearControl(hWnd, ID_REG_BUTTON2, "BUTTON", "", 265, 27, 70, 23, 0, WS_VISIBLE|WS_CHILD|WS_TABSTOP);
			SetWindowText(hWnd, rctitulo);
			SetWindowText(hrcStatic1, rctexto);
			SetWindowText(hrcStatic2, rcuser);
			SetWindowText(hrcStatic3, rcregkey);
			SetWindowText(hrcButton1, rcb1);
			SetWindowText(hrcButton2, rcb2);
			break;
		}
	}
	return FALSE;
}

Function(InputRegCode) //Listo!
{
	EXDLL_INIT();
	{
		char titulo[MAX_PATH]; char texto[MAX_PATH]; char lpuser[MAX_PATH]; char lpcode[MAX_PATH]; char lpkey[MAX_PATH]; char lpb1[MAX_PATH]; char lpb2[MAX_PATH]; char ret[MAX_PATH];
		popstring(titulo); popstring(texto); popstring(lpuser); popstring(lpcode); popstring(lpkey); popstring(lpb1); popstring(lpb2); popstring(ret);
		mi_strcpy(rctitulo, titulo); mi_strcpy(rctexto, texto); mi_strcpy(rcuser, lpuser); mi_strcpy(rcregkey, lpcode); mi_strcpy(rckey, lpkey); mi_strcpy(rcb1, lpb1); mi_strcpy(rcb2, lpb2); mi_strcpy(rcret, ret);
		CrearDlg(mi_hInst, hwnd, (DLGPROC)RegCodeProc);
	}
}

BOOL WINAPI DllMainCRTStartup(HINSTANCE hinstDLL,DWORD fdwReason,LPVOID lpReserved)
{
	mi_hInst = hinstDLL;
	return TRUE;
}
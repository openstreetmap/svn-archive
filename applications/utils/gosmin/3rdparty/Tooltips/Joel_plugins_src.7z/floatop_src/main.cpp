#include <windows.h>
#include <stdio.h>
#include "exdll.h"
#include "dll.h"

#define Function(name) extern "C" void __declspec(dllexport) name(HWND hwnd, int string_size, char *variables, stack_t **stacktop)

Function(Autor)
{
	EXDLL_INIT();
	{
		char ret[MAX_PATH];
		popstring(ret);
		RetVar(mi_atoi(ret), "Lobo Lunar");
	}
}

Function(Ver)
{
	EXDLL_INIT();
	{
		char ret[MAX_PATH];
		popstring(ret);
		RetVar(mi_atoi(ret), "2.0");
	}
}

Function(S)
{
	EXDLL_INIT();
	{
		char n1[MAX_PATH], n2[MAX_PATH], ret[MAX_PATH];
		popstring(n1); popstring(n2); popstring(ret);
		char dummy[MAX_PATH] = "\0";
		double d1 = atof(n1);
		double d2 = atof(n2);
		sprintf(dummy, "%g", d1+d2);
		RetVar(mi_atoi(ret), dummy);
	}
}

Function(R)
{
	EXDLL_INIT();
	{
		char n1[MAX_PATH], n2[MAX_PATH], ret[MAX_PATH];
		popstring(n1); popstring(n2); popstring(ret);
		char dummy[MAX_PATH] = "\0";
		double d1 = atof(n1);
		double d2 = atof(n2);
		sprintf(dummy, "%g", d1-d2);
		RetVar(mi_atoi(ret), dummy);
	}
}

Function(M)
{
	EXDLL_INIT();
	{
		char n1[MAX_PATH], n2[MAX_PATH], ret[MAX_PATH];
		popstring(n1); popstring(n2); popstring(ret);
		char dummy[MAX_PATH] = "\0";
		double d1 = atof(n1);
		double d2 = atof(n2);
		sprintf(dummy, "%g", d1*d2);
		RetVar(mi_atoi(ret), dummy);
	}
}

Function(D)
{
	EXDLL_INIT();
	{
		char n1[MAX_PATH], n2[MAX_PATH], ret[MAX_PATH];
		popstring(n1); popstring(n2); popstring(ret);
		char dummy[MAX_PATH] = "\0";
		double d1 = atof(n1);
		double d2 = atof(n2);
		sprintf(dummy, "%g", d1/d2);
		RetVar(mi_atoi(ret), dummy);
	}
}

BOOL WINAPI DllMain(HINSTANCE hinstDLL,DWORD fdwReason,LPVOID lpReserved)
{
	return TRUE;
}

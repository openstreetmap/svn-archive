#include <windows.h>
#include <commctrl.h>
#include "exdll.h"

#pragma comment(lib, "libctiny.lib")
#pragma comment(linker, "/defaultlib:kernel32.lib")
#pragma comment(linker, "/nodefaultlib:libc.lib")
#pragma comment(linker, "/nodefaultlib:libcmt.lib")
#pragma comment(linker, "/nodefaultlib:msvcrt.lib")

#if (_MSVC_VER < 1200)
		#pragma comment(linker,"/OPT:NOWIN98")
		#pragma comment(linker, "/merge:.rdata=.data")
		#pragma comment(linker, "/merge:.text=.data")
		#pragma comment(linker, "/merge:.reloc=.data")
		#pragma comment(linker,"/IGNORE:4078")
#endif

#define PLUGFUNC(myFunction) void __declspec(dllexport) myFunction(HWND hwndParent, int string_size, char *variables, stack_t **stacktop, extra_parameters *extra)


HWND GetListView(HWND hwndParent) {
	HWND hwndOwner = FindWindowEx(hwndParent,NULL,"#32770",NULL);
	return FindWindowEx(hwndOwner, NULL,"SysListView32", NULL);
}

int DisplayBillBoard(HWND hLv, char *pszImage, BOOL bShow) {
	LVBKIMAGE lvbki = {0};
	if (bShow) {
		lvbki.ulFlags = LVBKIF_SOURCE_URL|LVBKIF_STYLE_TILE;
		lvbki.pszImage = pszImage;
	}
	else {
		lvbki.ulFlags = LVBKIF_SOURCE_NONE;
	}
	return ListView_SetBkImage(hLv, &lvbki);
}

PLUGFUNC(Show) {
	EXDLL_INIT(); 
	{
		HWND hListView = GetListView(hwndParent);
		if (!hListView) {
			return;
		}
		else {
			char szBitmapPath[MAX_PATH];
			popstring(szBitmapPath);
			DisplayBillBoard(hListView, szBitmapPath, TRUE);
		}
	}

}

PLUGFUNC(Remove) {
	EXDLL_INIT(); 
	{
		HWND hListView = GetListView(hwndParent);
		if (!hListView) {
			return;
		}
		else {
			DisplayBillBoard(hListView, 0, FALSE);
		}
	}

}

BOOL WINAPI DllMain(HANDLE hInst, ULONG ul_reason_for_call, LPVOID lpReserved)
{
	return TRUE;
}

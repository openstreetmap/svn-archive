#include <windows.h>
#include <commctrl.h>
#include <string>
#include <vector>
#include "exdll.h"

using std::string;
using std::vector;

#pragma comment(lib, "libctiny.lib")
#pragma comment(linker, "/defaultlib:kernel32.lib")
#pragma comment(linker, "/nodefaultlib:libc.lib")
#pragma comment(linker, "/nodefaultlib:libcmt.lib")
#pragma comment(linker, "/nodefaultlib:msvcrt.lib")
#pragma comment(linker, "/nodefaultlib:msvcprt.lib")
#pragma comment (linker, "/entry:\"DllMainCRTStartup\"")
#if (_MSVC_VER < 1200)
#pragma comment(linker,"/OPT:NOWIN98")
#pragma comment(linker, "/merge:.rdata=.data")
#pragma comment(linker, "/merge:.text=.data")
#pragma comment(linker, "/merge:.reloc=.data")
#pragma comment(linker,"/IGNORE:4078")
#endif

#define PLUGFUNCTION(name) extern "C" void __declspec(dllexport) name(HWND hwndParent, int string_size, char *variables, stack_t **stacktop, extra_parameters *extra)

class CPoopy {
private:
	friend BOOL CALLBACK EnumWindowsProc(HWND hwnd, LPARAM lParam);
	BOOL bPoopy;
	HWND hWndParent;
	int nPoopy;
	vector<string> vWindows;
public:
	CPoopy() : bPoopy(false), hWndParent(NULL) {}
	CPoopy(HWND _h) : bPoopy(false), hWndParent(_h) {}
	CPoopy(bool _b) : bPoopy(_b), hWndParent(NULL) {}
	CPoopy(HWND _h, bool _b) : bPoopy(_b), hWndParent(_h) {}
	int myEnumWindows() {
		EnumWindows(EnumWindowsProc, 0);
		return 0;
	}
	HWND GetListView() {
		return GetLogWindow();
	}
	void LogMessage(const char *pStr) {
		LVITEM item = {0};
		HWND g_hwndList = GetLogWindow();
		int nItemCount = ListView_GetItemCount(g_hwndList);
		item.mask = LVIF_TEXT;
		item.pszText = (char *)pStr;
		item.cchTextMax = strlen(pStr);
		item.iItem = nItemCount;
		ListView_InsertItem(g_hwndList, &item);
		ListView_EnsureVisible(g_hwndList, item.iItem, 0);
		return;
	}
	const char* GetTitle(int i) {
		return vWindows[i].c_str();
	}
	int GetNumber() const {
		return nPoopy;
	}
	int myatoi(char *s) {
		int v=0;
		if (!s) return 0;
		if (*s == '0' && (s[1] == 'x' || s[1] == 'X')) {
			s++;
			for (;;) {
				int c=*(++s);
				if (c >= '0' && c <= '9') c-='0';
				else if (c >= 'a' && c <= 'f') c-='a'-10;
				else if (c >= 'A' && c <= 'F') c-='A'-10;
				else {
					break;
				}
				v<<=4;
				v+=c;
			}
		}
		else if (*s == '0' && s[1] <= '7' && s[1] >= '0') {
			for (;;)
			{
				int c=*(++s);
				if (c >= '0' && c <= '7') c-='0';
				else {
					break;
				}
				v<<=3;
				v+=c;
			}
		}
		else
		{
			int sign=0;
			if (*s == '-') {
				sign++; 
			}
			else {
				s--;
			}
			for (;;) {
				int c=*(++s) - '0';
				if (c < 0 || c > 9) {
					break;
				}
				v*=10;
				v+=c;
			}
			if (sign) {
				v = -v;
			}
		}
		if (*s == '|') {
			v |= myatoi(s+1);
		}
		return v;
	}
protected:
	HWND GetLogWindow() {
		HWND hwnd = FindWindowEx(hWndParent,NULL,"#32770",NULL);
		return FindWindowEx(hwnd, NULL,"SysListView32", NULL);
	}
};

CPoopy *pPoop; // A poop instance :)

BOOL CALLBACK EnumWindowsProc(HWND hwnd, LPARAM lParam){
	if (IsWindowVisible(hwnd)) {
		char szWindowTitle[MAX_PATH];
		int ret = GetWindowText(hwnd, szWindowTitle, sizeof(szWindowTitle)+1);
		if (ret) {
			if (!pPoop->bPoopy) {
				pPoop->LogMessage(szWindowTitle);
			}
			else {
				pPoop->nPoopy++;
				pPoop->vWindows.push_back(szWindowTitle);
			}
		}
	}
	return TRUE;
}

PLUGFUNCTION(Dump) {
	pPoop = new CPoopy(hwndParent, false);
	if (IsWindow(pPoop->GetListView())) {
		pPoop->myEnumWindows();
	}
	delete pPoop;
	return;
}

PLUGFUNCTION(Number) {
	EXDLL_INIT();
	pPoop = new CPoopy(hwndParent, true);
	if (IsWindow(pPoop->GetListView())) {
		pPoop->myEnumWindows();
		char tmp[8];
		int num = pPoop->GetNumber();
		wsprintf(tmp, "%i", num);
		setuservariable(0, tmp); // $0
	}
	return;
}

PLUGFUNCTION(Get) {
	EXDLL_INIT();
	if (pPoop) {
		char tmp[8];
		popstring(tmp);
		int item = pPoop->myatoi(tmp);
		setuservariable(1, pPoop->GetTitle(item)); // $1
	}
	return;
}

PLUGFUNCTION(Done) {
	if (pPoop) delete pPoop;
	return;
}

BOOL WINAPI DllMainCRTStartup(HANDLE hInst, ULONG ul_reason_for_call, LPVOID lpReserved) {
	return TRUE;
}
#include <windows.h>
#include <tlhelp32.h>
#include "exdll.h"

#pragma comment(lib, "libctiny.lib")
#pragma comment(linker, "/defaultlib:kernel32.lib")
#pragma comment(linker, "/nodefaultlib:libc.lib")
#pragma comment(linker, "/nodefaultlib:libcmt.lib")
#pragma comment(linker, "/nodefaultlib:msvcrt.lib")
#pragma comment (linker, "/entry:\"DllMainCRTStartup\"")

#if (_MSVC_VER < 1200)
		#pragma comment(linker,"/OPT:NOWIN98")
		#pragma comment(linker, "/merge:.rdata=.data")
		#pragma comment(linker, "/merge:.text=.data")
		#pragma comment(linker, "/merge:.reloc=.data")
		#pragma comment(linker,"/IGNORE:4078")
#endif

#define PLUGFUNC(myFunction) void __declspec(dllexport) myFunction(HWND hwndParent, int string_size, char *variables, stack_t **stacktop, extra_parameters *extra)

int NumberOfProccessByF(const char* pszEXE)
{
	PROCESSENTRY32 pe32 = {0};
	HANDLE hProcessSnap = NULL;
	int i = 0;
	hProcessSnap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
	if (hProcessSnap != INVALID_HANDLE_VALUE) {
		pe32.dwSize = sizeof(PROCESSENTRY32);
		if (Process32First(hProcessSnap, &pe32)) {
			HANDLE hProcess;
			hProcess = OpenProcess(PROCESS_ALL_ACCESS, FALSE, pe32.th32ProcessID);
			do {
				if (!lstrcmp(pe32.szExeFile, pszEXE)) i++;
				CloseHandle(hProcess);
			}while (Process32Next(hProcessSnap, &pe32));
		}
		CloseHandle(hProcessSnap);
	}
	return i;
}

PLUGFUNC(NumberOfProccessBy) {
	char pszExeFile[MAX_PATH], szNum[8];
	EXDLL_INIT();
	{
		popstring(pszExeFile);
		wsprintf(szNum, "%i", NumberOfProccessByF(pszExeFile));
		setuservariable(0, szNum);
	}
}

BOOL WINAPI DllMainCRTStartup(HANDLE hInst, ULONG ul_reason_for_call, LPVOID lpReserved) {
	return TRUE;
}
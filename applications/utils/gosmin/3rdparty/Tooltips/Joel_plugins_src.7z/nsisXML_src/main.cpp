#define BUILDVER TEXT("1.0.7")

#include <Windows.h>
#include "Main.h"
#include "ExDll.h"

#import "msxml2.dll" // mxml2.6 parser
using namespace MSXML2;

IXMLDOMDocumentPtr pXMLDoc;
char szFile[260];

FUNCTION(Build)
{
	EXDLL_INIT();
	char szRet[16];
	popstring(szRet);
	setuservariable(myatoi(szRet), BUILDVER);
	return;
}

FUNCTION(xPath)
{
	CoInitialize(NULL);
	IXMLDOMDocumentPtr pDoc;

	EXDLL_INIT();

	char lpStrFile[260], lpStrXPath[260], szRet[16];
	popstring(lpStrFile); 
	popstring(lpStrXPath); 
	popstring(szRet);

	pDoc.CreateInstance("MSXML2.DOMDocument");
	pDoc->load(lpStrFile);
	setuservariable(myatoi(szRet), pDoc->documentElement->selectSingleNode(lpStrXPath)->text);
	pDoc.Release();
	CoUninitialize();
	return;
}

FUNCTION(Create)
{
	IXMLDOMProcessingInstructionPtr pPI;
	EXDLL_INIT();
	CoInitialize(NULL);
	char szPI[260];
	popstring(szPI);

	pXMLDoc.CreateInstance("MSXML2.DOMDocument");
	pXMLDoc->preserveWhiteSpace = VARIANT_TRUE;
	pXMLDoc->async = VARIANT_TRUE;
	pXMLDoc->validateOnParse = VARIANT_TRUE;
	if (szPI[0] == 0)
	{
		pPI = pXMLDoc->createProcessingInstruction("xml", "version='1.0' encoding='UTF-8' standalone='yes'");
	}
	else
	{
		pPI = pXMLDoc->createProcessingInstruction("xml", szPI);
	}
	pXMLDoc->appendChild(pPI);
	pPI.Release();
	return;
}

FUNCTION(OpenXML)
{
	EXDLL_INIT();
	CoInitialize(NULL);
	char szXMLFile[260];
	popstring(szXMLFile);
	mylstrcpy(szFile, szXMLFile);
	pXMLDoc.CreateInstance("MSXML2.DOMDocument");
	pXMLDoc->load(szXMLFile);
	return;
}

FUNCTION(LoadXML)
{
	EXDLL_INIT();
	CoInitialize(NULL);
	char szXMLFile[260], szXML[260];
	popstring(szXMLFile);
	popstring(szXML);
	mylstrcpy(szFile, szXMLFile);
	pXMLDoc.CreateInstance("MSXML2.DOMDocument");
	pXMLDoc->preserveWhiteSpace = VARIANT_TRUE;
	pXMLDoc->async = VARIANT_TRUE;
	pXMLDoc->validateOnParse = VARIANT_TRUE;
	pXMLDoc->loadXML(szXML);
	return;
}

FUNCTION(CreateElement)
{
	EXDLL_INIT();
	if (pXMLDoc)
	{
		IXMLDOMElementPtr pElem;
		char szXPath[260], szNew[64], cLast[1];
		popstring(szXPath);
		popstring(szNew);
		popstring(cLast);
		char* temp = szXPath;
		if (temp[0] != 0)
		{
			pXMLDoc->documentElement->selectSingleNode(szXPath)->appendChild(pXMLDoc->createTextNode("\n\t"));
			pXMLDoc->documentElement->selectSingleNode(szXPath)->appendChild(pXMLDoc->createElement(szNew));
			if (cLast[0] != 0) pXMLDoc->documentElement->selectSingleNode(szXPath)->appendChild(pXMLDoc->createTextNode("\n"));
		}
		else
		{
			IXMLDOMElementPtr pElem;
			pElem = pXMLDoc->createElement(szNew);
			pXMLDoc->appendChild(pElem);
			pElem.Release();
		}
	}
	return;
}

FUNCTION(SetElementText)
{
	EXDLL_INIT();
	if (pXMLDoc)
	{
		char szXPath[260], szTxt[64];
		popstring(szXPath);
		popstring(szTxt);
		pXMLDoc->documentElement->selectSingleNode(szXPath)->Puttext(szTxt);
	}
	return;
}

FUNCTION(SetElementAttr)
{
	EXDLL_INIT();
	if (pXMLDoc)
	{
		IXMLDOMAttributePtr pAttr;
		char szXPath[260], szAttr[64], szTxt[64];
		popstring(szXPath);
		popstring(szAttr);
		popstring(szTxt);
		pAttr = pXMLDoc->createAttribute(szAttr);
		pAttr->value = szTxt;
		pXMLDoc->documentElement->selectSingleNode(szXPath)->attributes->setNamedItem(pAttr);
		pAttr.Release();
	}
	return;
}

FUNCTION(CreateComment)
{
	EXDLL_INIT();
	if (pXMLDoc)
	{
		char szXPath[260], szComm[260];
		popstring(szXPath);
		popstring(szComm);
		//pXMLDoc->documentElement->selectSingleNode(szXPath)->appendChild(pXMLDoc->createTextNode("\n\t"));
		pXMLDoc->documentElement->selectSingleNode(szXPath)->appendChild(pXMLDoc->createComment(szComm));
	}
	return;
}

FUNCTION(Display)
{
	EXDLL_INIT();
	if ( (pXMLDoc) & (pXMLDoc->parseError->errorCode == 0) )
	{
		MessageBox(hwndParent, pXMLDoc->xml, "XML tree", 64);
	}
	return;
}

FUNCTION(RemoveChild)
{
	EXDLL_INIT();
	if (pXMLDoc) 
	{
		char szXPath[260], szIndex[16];
		popstring(szXPath);
		popstring(szIndex);
		pXMLDoc->documentElement->selectSingleNode(szXPath)->removeChild(pXMLDoc->documentElement->childNodes->Getitem(myatoi(szIndex)));
	}
	return;
}

FUNCTION(RemoveAttr)
{
	EXDLL_INIT();
	if (pXMLDoc)
	{
		char szXPath[260], szAttr[128];
		popstring(szXPath);
		popstring(szAttr);
		pXMLDoc->documentElement->selectSingleNode(szXPath)->attributes->removeNamedItem(szAttr);
	}
	return;
}

FUNCTION(Release)
{
	EXDLL_INIT();
	if (pXMLDoc) 
	{
		char lpStrFile[260];
		popstring(lpStrFile);
		pXMLDoc->save(lpStrFile);
		pXMLDoc.Release();
	}
	CoUninitialize();
	return;
}

FUNCTION(xml)
{
	EXDLL_INIT();
	if (pXMLDoc)
	{
		char szRet[260];
		popstring(szRet);
		setuservariable(myatoi(szRet), pXMLDoc->xml);
	}
	return;
}

FUNCTION(CloseXML)
{
	EXDLL_INIT();
	if (pXMLDoc)
	{
		if (pXMLDoc->parseError->errorCode == 0)
		{
			
			pXMLDoc->save(szFile);
		}
		pXMLDoc.Release();
		szFile[0] = '\0';
	}
	CoUninitialize();
	return;
}

FUNCTION(TidyFile)
{
	EXDLL_INIT();
	if (pXMLDoc)
	{
		IXMLDOMElementPtr pElem = pXMLDoc->documentElement;
		if (pElem)
		{
			pXMLDoc->save(szFile);
			pElem.Release();
		}
	}
	return;
}

FUNCTION(parseError)
{
	EXDLL_INIT();
	if (pXMLDoc)
	{
		char szRet[5];
		popstring(szRet);
		if (pXMLDoc->parseError->errorCode == 0)
		{
			setuservariable(myatoi(szRet), "");
		}
		else
		{
			setuservariable(myatoi(szRet), (LPCSTR)pXMLDoc->parseError->reason);
		}
	}
	return;
}

FUNCTION(TestBegin)
{
	EXDLL_INIT();
	pXMLDoc.CreateInstance("MSXML2.DOMDocument");
	pXMLDoc->preserveWhiteSpace = VARIANT_TRUE;
	pXMLDoc->async = VARIANT_TRUE;
	pXMLDoc->validateOnParse = VARIANT_TRUE;
	return;
}

FUNCTION(TestXML)
{
	EXDLL_INIT();
	if (pXMLDoc)
	{
		char szXML[260];
		popstring(szXML);
		pXMLDoc->loadXML(szXML);
	}
	return;
}

FUNCTION(TestFile)
{
	EXDLL_INIT();
	if (pXMLDoc)
	{
		char szXML[260];
		popstring(szXML);
		pXMLDoc->load(szXML);
	}
	return;
}

FUNCTION(TestShow)
{
	EXDLL_INIT();
	if (pXMLDoc)
	{
		IXMLDOMElementPtr pElem = pXMLDoc->documentElement;
		if (pElem)
		{
			MessageBox(hwndParent, pXMLDoc->xml, "XML", 64);
			pElem.Release();
		}
	}
	return;
}

FUNCTION(TestEnd)
{
	EXDLL_INIT();
	if (pXMLDoc)
	{
		pXMLDoc.Release();
	}
	return;
}

BOOL WINAPI DllMain(HANDLE hInst, ULONG ul_reason_for_call, LPVOID lpReserved)
{
	return TRUE;
}


#define FUNCTION(name) extern "C" void __declspec(dllexport) name(HWND hwndParent, int string_size, char *variables, stack_t **stacktop, extra_parameters *extra)

int myatoi(char *s)
{
	int v=0;
	if (!s)
	{
		return 0;
	}
	if (*s == '0' && (s[1] == 'x' || s[1] == 'X'))
	{
		s++;
		for (;;)
		{
			int c=*(++s);
			if (c >= '0' && c <= '9')
			{
				c-='0';
			}
			else if (c >= 'a' && c <= 'f')
			{
				c-='a'-10;
			}
			else if (c >= 'A' && c <= 'F')
			{
				c-='A'-10;
			}
			else
			{
				break;
			}
			v<<=4;
			v+=c;
		}
	}
	else if (*s == '0' && s[1] <= '7' && s[1] >= '0')
	{
		for (;;)
		{
			int c=*(++s);
			if (c >= '0' && c <= '7') c-='0';
			else
			{
				break;
			}
			v<<=3;
			v+=c;
		}
	}
	else
	{
		int sign=0;
		if (*s == '-')
		{
			sign++; 
		}
		else
		{
			s--;
		}
		for (;;)
		{
			int c=*(++s) - '0';
			if (c < 0 || c > 9)
			{
				break;
			}
			v*=10;
			v+=c;
		}
		if (sign)
		{
			v = -v;
		}
	}
	if (*s == '|') 
	{
		v |= myatoi(s+1);
	}
	return v;
}

int mylstrcpy(char* buffer, const char* cadena)
{
	int index = 0;
	int i = 0;
	while(cadena[i] != '\0')
	{
		buffer[index] = cadena[i];
		index++;
		i++;
	}
	buffer[index] = 0;
	return i;
}

int mylstrcpyn(char* buffer, const char* cadena, int chars)
{
	int index = 0;
	for(int i = 0; i < chars; i++)
	{
		buffer[index] = cadena[i];
		index++;
	}
	buffer[index] = 0;
	return i;
}

/*
BSTR WINAPI CreateUnicodeStr(const char* s)
{
	int lenW = MultiByteToWideChar(CP_ACP, 0, s, -1, 0, 0);
	BSTR bSTR = SysAllocStringLen(0, lenW);
	MultiByteToWideChar(CP_ACP, 0, s, -1, bSTR, lenW);
	return bSTR;
}

VOID WINAPI FreeUnicodeStr(BSTR bStr)
{
	return SysFreeString(bStr);
}
*/